# Pırıl v1.2.0: Eğlence ve ödül güncellemesi

v1.1.0'daki ebeveyn kontrollerinin ve yeni tasarımın üzerine kuruludur. Amaç, uygulamanın çocuğa
canlı ve ödüllendirici gelmesidir.

## Yenilikler
- **Ses efektleri:** Dokunma, kart çevirme, doğru ve yanlış cevap, yıldız ve kutlama sesleri. Sesler
  ses dosyası olmadan, Web Audio ile üretilir; internet gerekmez. Ebeveyn Paneli → Ayarlar →
  "Ses efektleri" ile kapatılabilir.
- **Kutlama ekranı:** Yeni rozet kazanıldığında, ödül hedefine ulaşıldığında ya da yeni bir aksesuar
  açıldığında ışıltılı rozet, konfeti, kutlama müziği ve sevinen Pırıl görünür. Aynı anda birden fazla
  kutlama varsa sırayla gösterilir.
- **Rozet albümü:** Ana ekrandaki rozet satırına ("Tümü ›") dokununca 15 rozetin hepsi açılır. Her
  rozetin nasıl kazanılacağı ve çocuğun ilerlemesi (ör. 19 / 20) görünür.
- **Uçan yıldızlar:** Kazanılan yıldızlar ekranın ortasından yıldız sayacına uçar, sayaç zıplar.
- **Pırıl'ı süsle:** Yıldız topladıkça Pırıl'ın dolabına aksesuar gelir: Fiyonk (hemen), Gözlük (15 ⭐),
  Papyon (30 ⭐), Parti şapkası (50 ⭐), Çiçek (80 ⭐), Taç (120 ⭐). Seçilen aksesuar ana ekranda,
  sohbette, oyunlarda, kilit ekranlarında ve kutlamalarda görünür. Seçim profile özeldir ve yedeğe dahildir.
- **Oyunlarda Pırıl:** Oyunlardaki yardımcı artık Pırıl. Doğru cevapta sevinir ve zıplar.
- **Dokununca kıkırdar:** Ana ekrandaki Pırıl'a dokununca güler ve neşeli bir cümle söyler.
  Sohbet ekranında dokununca da sevinir.
- **Saate göre selamlama:** "Günaydın", "Merhaba", "İyi akşamlar", "İyi geceler".

## Sürüm
- versionCode 5, versionName 1.2.0
- Yeni Android izni yok.
