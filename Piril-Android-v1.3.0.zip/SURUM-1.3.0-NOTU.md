# Pırıl v1.3.0: Zekâ ve kodlama güncellemesi (7+ yaş)

Bu sürüm, zekâ oyunlarını "oynayıp geçilen" oyunlardan "bir şey öğreten" oyunlara dönüştürür.
Her bölümün sonunda çocuk yıldız puanını ve motive edici bir söz görür.

## 1. Kodlama Yolu (Kod Macerası): 7 bölüm, 25 görev

Bu sıra; Code.org (CS Fundamentals), Blockly Games (Maze) ve Lightbot'ta kullanılan sıraya dayanır.
Her görev yeni bir fikir öğretir, aynı bulmaca iki kez sorulmaz.

| Bölüm | Kavram | Görevler | Çocuğun kazandığı alışkanlık |
|---|---|---|---|
| 📜 1 Sıra | Komutlar sırayla çalışır | Uyanış, İlk Dönüş, Kayayı Dolaş, İki Yıldız | Adım adım düşünmek, yön kavramı |
| 🐞 2 Hata Ayıklama | Hazır ama hatalı programı düzeltmek | Ters Dönüş, Eksik Adım, Yanlış Sıra | Hatadan korkmamak, hatayı bulup düzeltmek |
| 🔁 3 Döngü | TEKRAR, iç içe döngü | Uzun Yol, Yıldız Dizisi, Kare Çiz, Merdiven | Tekrar eden kalıbı görmek |
| 🎁 4 Fonksiyon | Kendi komutunu (BECERİ) yapmak | Çapraz Adım, Çim Biçme, Büyük Bahçe | Büyük işi parçalara bölmek |
| ❓ 5 Koşul | EĞER / DEĞİLSE, birden çok harita | Yıldız Var mı?, Hangi Yol?, Tarayıcı Robot | Her durumda çalışan program yazmak (test) |
| 🔄 6 …Olana Kadar | Ne zaman duracağını bilmek (while) | Duvara Kadar, Yıldız Yağmuru, Kıvrımlı Yol, Labirent Ustası | Algoritma kurmak (sağ el kuralı) |
| 💻 7 Gerçek Kod | Python yazmak | Merhaba Python, for Döngüsü, while ve if, def ile Usta İşi | Bloklardan gerçek koda geçmek |

Çocuğun kavramı gerçekten kullanmasını sağlayan kurallar:
- **Blok sınırı:** Örneğin "Uzun Yol" görevinde en fazla 3 blok kullanılabilir. Çocuk 8 tane İLERİ dizemez,
  TEKRAR bloğunu kullanmak zorunda kalır. Sınır aşılırsa Pırıl hangi bloğu denemesi gerektiğini söyler.
- **Birden çok harita:** Koşul ve döngü bölümlerinde aynı program 2-3 farklı haritada denenir. Sadece tek
  haritayı ezberleyen program geçemez. Bu, yazılımcıların "test" alışkanlığının çocuk hâlidir.
- **Hata ayıklama görevleri:** Program hazır gelir ama içinde bir hata vardır. Çalıştırınca hatanın olduğu
  blok kırmızıyla gösterilir.
- **3 yıldız:** En kısa çözüm 3 yıldız, biraz uzunu 2 yıldız alır. Kart, en kısa çözümün kaç blok olduğunu
  söyler ve çocuğu tekrar denemeye davet eder.
- **Adım adım izleme:** Program çalışırken o an çalışan blok (Python'da satır) sarıyla yanar.
  Hız düğmesi: 🐢 Yavaş · 🚶 Normal · 🐇 Hızlı.
- **Her zaman gerçek kod:** "💻 Python" düğmesi, blok programının Python karşılığını gösterir
  (TEKRAR → for, EĞER → if, DEĞİLSE → else, …KADAR TEKRARLA → while, BECERİ → def).
- **7. bölümde Python yazılır:** Hazır kod parçalarına dokunarak ya da klavyeyle yazılır. Hata olursa Pırıl
  hangi satırda olduğunu Türkçe söyler (ör. "2. satırda: zipla() diye bir fonksiyon yok").
- Yatay tablette harita solda, bloklar sağda durur. Harita program uzasa da ekranda kalır.

Önceki sürümün 12 görevlik ilerlemesi yeni yola şöyle taşınır: Sıra ve Hata Ayıklama bölümleri açık gelir,
çocuk Döngü bölümünden devam eder. Kazanılmış rozetler kalır.

Bütün görevlerin çözümleri, oyunun kendi yorumlayıcısıyla otomatik olarak doğrulandı. Her görevin
çözülebilir olduğu, blok sınırına uyduğu ve hata ayıklama görevlerindeki hazır programın gerçekten hatalı
olduğu kontrol edildi.

## 2. Sudoku v2

- **Boyutlar:** 4×4 (başlangıç), 6×6 (7+ yaş), 9×9 (usta). Her boyutta Kolay / Orta / Zor seçilebilir.
- Her bulmaca yeniden üretilir ve **tek çözümlüdür**. Mantıkla çözülür, tahmin gerekmez.
- **Kurallara göre kontrol:** Çocuğun yanlış yerleştirdiği sayı kırmızıyla gösterilir ve nedeni söylenir.
- Seçilen karenin satırı, sütunu ve kutusu açık renkle gösterilir; aynı sayılar sarıyla işaretlenir.
- **💡 Nedenli ipucu:** İpucu cevabı vermekle kalmaz, nedenini de söyler:
  - **TEK ADAY:** "Bu karenin satırı, sütunu ve kutusunda 1, 3, 4, 5, 6 var. Geriye sadece 2 kalıyor!"
  - **GİZLİ TEK:** "Bu satırda 4 sayısı başka hiçbir kareye sığmıyor, sadece buraya!"
- Süre, çakışma ve ipucu sayısı görünür. Yıldız puanı bunlara göre verilir.

## 3. Yeni oyun: 📊 Veri Dedektifi (temel istatistik)

"Öğrenelim" bölümündedir. Her tur 5 görevden oluşur ve görevler her seferinde yeniden üretilir.

| Mod | Öğrettiği |
|---|---|
| 📊 Say ve Grafiğe Dök | Veri toplama, sayma, sütun grafiği çizme |
| 🔎 Grafik Oku | En çok olan (mod), en az olan, fark, toplam |
| ⚖️ Ortalama | Kuleleri eşitleyerek ortalamayı bulma (toplam ÷ adet) |
| 🎲 Şans Torbası | Olasılık dili (imkânsız / mümkün / kesin) ve kesir (6/14) |

Her doğru cevaptan sonra Pırıl kavramın adını söyler. Örnek: "8 ÷ 4 = 2. Herkes eşit pay aldı:
bu sayıya ORTALAMA denir!"

## 4. Görev tamam kartı ve motive edici sözler

- Kod görevi, Sudoku, Veri Dedektifi turu, Hafıza ve Harf Avı bitince kart açılır. Kartta 3 yıldızlık
  puan, kısa bir özet ve motive edici bir söz bulunur. Söz sesli okunur.
- Toplam 49 söz ve "Biliyor muydun?" bilgisi vardır: kodlama (18), mantık (7), veri (7) ve genel (17).
  Örnekler: Atatürk, Einstein, Marie Curie, atasözleri, Ada Lovelace ve "bug" kelimesinin hikâyesi.
- Sözler tekrar etmez: bir gruptaki sözlerin hepsi görülmeden aynı söz yeniden çıkmaz.
- "Sonraki görev ▶" ile doğrudan devam edilir.

## 5. Rozetler

- Yeni rozetler: 🐍 **Python Kâşifi** (22. görev) ve 📊 **Veri Dedektifi** (5 tur). Toplam 17 rozet var.
- "Küçük Kodcu" rozeti artık Hata Ayıklama bölümünün sonunda (7. görev), "Kod Ustası" rozeti 25 görevin
  sonunda kazanılır.

## Çocuğunuz için önerilen yol

1. **Blok bölümleri (1-6):** Günde 2-3 görev yeterlidir. Hızlı geçmek yerine 3 yıldızı hedeflemesini
   isteyin. Zorlandığında 💡 düğmesi cevabı vermeden ipucu verir.
2. **"💻 Python" düğmesi:** Her görevden sonra bloklarının gerçek kod karşılığına birlikte bakın.
3. **Gerçek Kod bölümü (7):** Yazarak kodlamaya geçiş. Hata mesajlarını birlikte okumak çok öğreticidir.
4. **Sonraki adımlar (uygulama dışında):** Scratch (proje yapmak), micro:bit veya basit robot kitleri
   (gerçek dünyada kod), 10+ yaşta bilgisayarda Python (Thonny editörü, kaplumbağa grafikleri).

## Sürüm
- versionCode 6, versionName 1.3.0
- Yeni Android izni yok. Her şey internetsiz çalışır.
