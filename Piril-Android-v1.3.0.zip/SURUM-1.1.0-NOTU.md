# Pırıl v1.1.0: Ebeveyn güvenliği ve yeni özellikler

Bu sürüm v1.0.2'nin (ücretsiz, cihaz içi yapay zekâ) üzerine kuruludur. Değişiklikler bir ebeveyn
gözüyle yapıldı: çocuğun güvenliği, ekran süresinin adil sayılması ve ebeveynin gerçekten
kontrol edebilmesi.

## Ebeveyn kontrolü
- **İlk açılışta ebeveyn PIN'i belirlenir.** Eskiden PIN ekranında "ilk kullanımda: 1234" yazıyordu;
  çocuk bunu okuyabiliyordu. Artık varsayılan PIN yok. 1234 ve 0000 gibi tahmini kolay PIN'ler kabul edilmez.
  PIN iki kez girilerek onaylanır.
- **Yanlış PIN kilidi:** 5 yanlış denemeden sonra tuş takımı 30 sn kilitlenir. Her yeni hatada süre
  30 sn uzar (en fazla 5 dk). Uygulamayı kapatıp açmak kilidi kaldırmaz.
- **Profil ekleme, düzenleme ve silme PIN ister.** Eskiden çocuk yeni bir profil açarak günlük süre
  sınırını atlatabiliyor, kendi kayıtlarını silebiliyordu.
- **Kullanım saatleri:** Örneğin 08:00–20:30. Bu saatlerin dışında kartlar 🌙 ile kapanır.
  İsterseniz dinlenme saatinde yalnızca Uyku Masalı açık kalır.
- **Ebeveynden +15 dk:** Süre dolduğunda ya da dinlenme saatinde kilit ekranındaki
  "🔒 Ebeveyn: +15 dk" düğmesiyle PIN girilerek o güne ek süre verilir.
- **Göz molası artık gerçekten 20 saniye:** "Devam et" düğmesi geri sayım bitene kadar kapalıdır.
- **Süre dolmuş profile tekrar girilemez** (eskiden birkaç saniye daha kullanılabiliyordu).

## Güvenlik
- **Yapay zekâ cevap filtresi:** Küçük cihaz içi model kurallara her zaman uymayabilir. Uygunsuz kelime
  içeren bir cevap çocuğa hiç gösterilmez; yerine "başka bir şeyden konuşalım" denir. Engellenen
  cevap ebeveyn kayıtlarına "🛡️ CEVAP ENGELLENDİ" olarak düşer. Cevaplardaki internet adresleri silinir.
- **Kişisel bilgi koruması:** Çocuk telefon numarası, adres, e-posta, T.C. kimlik no, okul adı ya da
  şifre söylerse bu bilgi modele gönderilmez. Pırıl bu bilgilerin özel olduğunu anlatır. Kayıtta
  rakamlar maskelenir ("🔒 KİŞİSEL BİLGİ").
- **Hassas konu listesi genişletildi:** Zorbalık, tehdit, istenmeyen dokunma ve kendine zarar verme
  ifadelerinde Pırıl çocuğu güvendiği bir yetişkine yönlendirir.
- **Ebeveyne uyarı:** Yeni bir uyarı olduğunda 🔒 düğmesinde kırmızı nokta görünür. Ebeveyn Paneli
  açılınca "Dikkat etmeniz gereken N yeni konuşma var" bandı çıkar. "Konuşmaları kaydet" kapalı
  olsa bile güvenlik uyarıları kaydedilir.

## Ebeveyn raporu
- **Son 7 günün ekran süresi grafiği:** Toplam süre ve kullanılan günlerdeki ortalama gösterilir.
  Bir güne dokununca o günün süresi görünür. Günlük sınır açıksa grafikte çizgi olarak görünür.
- **Bu hafta en çok:** Çocuğun süresini en çok hangi etkinliklerde geçirdiği listelenir.

## Çocuk için
- **Ödül hedefi:** Ebeveyn her profil için bir ödül ve yıldız hedefi belirler (ör. "Hafta sonu parka
  gitmek: 20 ⭐"). Çocuk ilerlemesini ana ekranda görür ve hedefe ulaşınca kutlama yapılır.
- **Yeni oyun: Harf Avı** (internet gerektirmez). Türk alfabesindeki harflerle başlayan resimleri bulma
  (Kolay: 3 resim, Orta: 4 resim) ya da resmin baş harfini bulma (Zor). Pırıl sesli yönlendirir;
  yanlış cevapta seçilen resmin adını ve hangi harfle başladığını söyler. Yeni rozet: 🔤 Harf Ustası.
  Ğ, I ve J harfleri dahil değildir (Ğ ile kelime başlamaz; I ve J için karışıklığa yol açmayan resim yok).

## Yeni görsel tasarım
- **Pırıl maskotu:** Uygulama simgesindeki güneş artık uygulamanın içinde de Pırıl'ın kendisidir. Rengi
  çocuğun seçtiği renge uyar. Göz kırpar, ışınları yavaşça döner ve hafifçe süzülür. Dinlerken ağzı "o"
  şeklini alır, konuşurken ağzı hareket eder, düşünürken gözleri yukarı bakar. Dinlenme ekranında
  uyur ("z z"), göz molasında gözlerini kapatır, süre dolunca gülümser.
- **Açılış ekranı:** Mor zemin üzerinde sarı Pırıl ve "Çocuklar için konuşan arkadaş" yazısı.
- **Yazı tipleri:** Başlık ve düğmelerde Baloo 2, metinlerde Nunito. İkisi de Türkçe karakterlerin tamamını
  içerir ve uygulamanın içine gömülüdür (internet gerekmez; SIL OFL 1.1, lisanslar `www/fonts/` klasöründe).
  Önceki tasarımın kullandığı Fredoka yazı tipinde ğ, ş ve İ harfleri yoktu.
- **Tutarlı ikonlar:** Geri, kilit, profil, tekrar dinle, dur, klavye, ipucu ve ses düğmeleri tek tip
  çizgi ikonlarla çizildi. Emoji yalnızca içerikte (etkinlikler, oyunlar) kullanılır.
- **Düğmeler:** Basınca içe gömülen "3B" düğmeler ve renkli ana düğmeler.
- **Ana ekran:** Karşılama kartı (maskot, ödül hedefi, rozetler) ve renkli ikon kutulu etkinlik kartları.
  Kartlar tablet genişliğinde 4 sütun hâlinde ekranı doldurur.
- **Geçişler:** Ekranlar yumuşak geçişle açılır, pencereler yaylanarak gelir, kartlar sırayla belirir,
  konuşma balonu Pırıl'ı gösteren bir okla açılır.
- **Oyunlar:** Hafıza kartları 3B olarak döner (desenli kart arkası). Satranç tahtası çerçeveli ve kareleri
  eşittir; seçili kare ve son hamle yumuşak renklerle vurgulanır. Sudoku, Örüntü ve Harf Avı'nda büyük,
  dokunması kolay taşlar var. Doğru cevapta taş zıplar, yanlışta sallanır.
- **Profil ekranı:** Tepe ve bulut manzarası. Her profil kartında çocuğun rengiyle çerçevelenmiş avatar.
- Gece teması bu tasarımla uyumludur. Android'de "hareketi azalt" seçeneği açıksa animasyonlar kapanır.

## Teknik iyileştirmeler
- **Android geri tuşu** artık uygulamadan çıkmaz; önce pencereyi kapatır, sonra ana ekrana döner.
  Yalnızca profil seçim ekranında uygulamadan çıkılır. Kilit ekranları geri tuşuyla kapatılamaz.
- **Arka planda süre sayılmaz.** Eskiden uygulama arka plandayken ya da ekran kapalıyken de süre
  sayılmaya devam ediyordu.
- **4 dakika dokunulmazsa** süre sayımı durur ve ekranın uykuya geçmesine izin verilir. Uygulama
  açık unutulduğunda ekran sabaha kadar yanık kalmaz. Pırıl konuşurken ya da dinlerken bu süre işlemez.
- **Mobil veri uyarısı:** 550 MB'lık model, mobil veri ya da kotalı ağ üzerinden indirilmeden önce onay ister.
- **"Modeli sil" düğmesi düzeltildi.** Eski sürümde kullanılan tarayıcı onay penceresi (`confirm`)
  Android WebView'da görünmediği için model hiç silinemiyordu. Artık uygulama içi bir onay penceresi açılıyor.
- **Yedekle / geri yükle:** Ebeveyn Paneli → Ayarlar → Yedekleme. Yedek, Android'in paylaş menüsüyle
  Drive'a, e-postaya ya da mesaja kaydedilir. Geri yüklemek için yedek metni yapıştırılır. PIN yedeğe
  dahil değildir. Uygulama verileri Android yedeğine alınmadığından (allowBackup=false), yeniden
  kurulumda verileri korumanın tek yolu budur.
- **Günlük süre yerel saate göre sıfırlanır.** Eskiden UTC'ye göre, yani Türkiye'de saat 03:00'te sıfırlanıyordu.

## Sürüm
- versionCode 4, versionName 1.1.0
- Yeni Android izni: `ACCESS_NETWORK_STATE` (yalnızca mobil veri kontrolü için)
