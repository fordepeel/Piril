Baloo 2 ve Nunito yazı tipleri index.html içine gömülüdür (base64 woff2, latin + latin-ext).
İkisi de SIL Open Font License 1.1 ile lisanslıdır; lisans metinleri bu klasördedir.
Kaynak: Fontsource (@fontsource-variable/baloo-2, @fontsource-variable/nunito 5.3.0).
