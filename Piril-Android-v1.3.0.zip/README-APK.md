# Pırıl Android v1.3.0

Pırıl, çocuklarla Türkçe konuşan, hikâye anlatan ve oyun oynayan bir yapay zekâ arkadaşıdır.
Yapay zekâ modeli (Qwen2.5-0.5B) doğrudan tablette çalışır: API anahtarı ya da kullanım ücreti yoktur.
Arayüz ve internetsiz oyunlar (satranç, hafıza, örüntü, sudoku, Harf Avı, Veri Dedektifi, Kod Macerası) internet olmadan çalışır.

Android katmanı şunları sağlar:

- Türkçe Android konuşma tanıma ve metin okuma köprüsü
- Cihaz içi yapay zekâ modelini indirme ve çalıştırma (MediaPipe / LiteRT)
- Tam ekran çalışma; geri tuşu uygulama içinde geri gider
- Yedeği Android paylaş menüsüyle kaydetme

Uygulama kimliği: `com.selcukz.piril` · Minimum Android sürümü: Android 8.0 (API 26)

## Tablete kurulum

1. APK dosyasını tablete gönderin ve dosyaya dokunun. Android isterse, dosyayı açtığınız uygulama için
   **Bilinmeyen uygulamaları yükle** iznini verin.
2. **Yükle**, ardından **Aç** deyin.
3. İlk açılışta **sadece sizin bileceğiniz 4 haneli bir ebeveyn PIN'i** belirleyin.
4. Çocuğunuz için bir profil oluşturun. İsterseniz bir ödül hedefi de ekleyin.
5. Wi-Fi'ye bağlıyken **Ücretsiz modeli indir** ile yaklaşık 550 MB'lık modeli bir kez indirin.
6. İlk mikrofon kullanımında **Uygulamayı kullanırken izin ver** seçeneğini seçin.
7. Ebeveyn Paneli → Ayarlar bölümünden süre sınırı, kullanım saatleri ve mola hatırlatıcısını ayarlayın.

## Güncelleme notu

Bir APK başka bir imza anahtarıyla imzalanmışsa, tablette kurulu eski sürümün üzerine kurulamaz.
Bu durumda önce Ebeveyn Paneli → Ayarlar → **Yedeği paylaş** ile yedek alın, eski sürümü kaldırın,
yeni sürümü kurun ve **Yedekten geri yükle** ile verileri geri getirin.

Yenilikler: `SURUM-1.3.0-NOTU.md`, `SURUM-1.2.0-NOTU.md` ve `SURUM-1.1.0-NOTU.md`
