# Pırıl v1.0.2 — Ücretsiz cihaz içi yapay zekâ

Bu sürümde ücretli bulut yapay zekâ entegrasyonları tamamen kaldırılmıştır.

- Model: Qwen2.5-0.5B-Instruct (dynamic INT8, MediaPipe/LiteRT uyumlu)
- Lisans: Apache-2.0
- Model kaynağı: LiteRT Community / Hugging Face
- Model boyutu: yaklaşık 550 MB
- Çalışma biçimi: Android cihaz üzerinde CPU çıkarımı
- API anahtarı: yok
- Kullanım başına ücret: yok
- İlk kurulum: model dosyası bir kez indirilir
- Sonraki kullanım: yapay zekâ metin üretimi çevrimdışı çalışabilir

Android konuşma tanımanın da çevrimdışı olması için cihazda Türkçe çevrimdışı konuşma paketi bulunmalıdır. Android TTS, cihazdaki Türkçe ses paketini kullanır.

Çizim alanı korunmuştur; ancak bu sürümde kullanılan metin modeli görüntü analizi yapmaz ve kullanıcıya çizimi gördüğünü iddia etmez.
