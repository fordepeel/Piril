# Pırıl Android

Bu proje, Pırıl web uygulamasını Android APK içinde çevrimdışı olarak taşır.
Arayüz ve yerel oyunlar internet olmadan açılır. OpenAI yanıtları ve cihazın
çevrim içi konuşma tanıma hizmeti için internet gerekir.

Android katmanı şunları sağlar:

- Türkçe Android konuşma tanıma köprüsü
- Android Türkçe metin okuma köprüsü
- OpenAI API anahtarını Android Keystore ile şifreli saklama
- OpenAI isteklerini WebView yerine yerel HTTPS bağlantısıyla gönderme
- Tam ekran ve adres çubuksuz çalışma

Uygulama kimliği: `com.selcukz.piril`

Minimum Android sürümü: Android 8.0 (API 26)

## Tablete kurulum

1. `Piril-v1.0.1-openai.apk` dosyasını tablete gönderin.
2. Dosyaya dokunun. Android isterse, dosyayı açtığınız uygulama için
   **Bilinmeyen uygulamaları yükle** iznini etkinleştirin.
3. **Yükle** düğmesine dokunun ve ardından **Aç** deyin.
4. Pırıl içinde kilit simgesi → PIN `1234` → **Ayarlar** yolundan OpenAI
   API anahtarını kaydedin ve PIN'i değiştirin.
5. İlk mikrofon kullanımında **Uygulamayı kullanırken izin ver** seçeneğini
   seçin.
6. Pırıl'ın Ayarlar ekranındaki **Türkçe ses ayarını aç** düğmesinden Türkçe
   metin okuma sesini yükleyin/seçin.

## Güncelleme notu

Gelecek APK sürümleri aynı `piril-release-key.p12` anahtarıyla imzalanmalıdır.
`Piril-Imza-Yedegi-v1.0.1.zip` dosyasını özel ve güvenli bir yerde saklayın.
