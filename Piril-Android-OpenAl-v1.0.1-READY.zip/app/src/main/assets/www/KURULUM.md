# Pırıl Android v1.0.2 Offline — Kurulum

Pırıl bu sürümde ücretli bir yapay zekâ API'si kullanmaz. Yapay zekâ modeli doğrudan Android tablette çalışır.

## İlk kurulum

1. APK'yi kurun ve Pırıl'ı açın.
2. Açılışta “Ücretsiz yapay zekâ modeli” penceresi görünür.
3. **Ücretsiz modeli indir** düğmesine dokunun.
4. Yaklaşık 550 MB büyüklüğündeki Qwen2.5-0.5B-Instruct modeli bir kez indirilir.
5. İndirme tamamlandıktan sonra sohbet, hikâye, bilgi ve oyun ipuçları cihaz üzerinde çalışır.

Model açık kaynak Apache-2.0 lisanslı Qwen2.5-0.5B-Instruct LiteRT/MediaPipe sürümüdür. Model dosyası Hugging Face üzerindeki LiteRT Community deposundan indirilir.

## Ücret

Pırıl'ın yapay zekâ konuşmaları için API anahtarı, abonelik veya kullanım başına ücret gerekmez. Model indirildikten sonra metin üretimi cihaz üzerinde yapılır.

## İnternet ne zaman gerekir?

Yapay zekâ modeli ilk kez indirilirken internet gerekir. Model kurulduktan sonra yapay zekâ cevabı için internet gerekmez. Android'in konuşmayı yazıya çevirme özelliğinin de tamamen çevrimdışı çalışması için cihazda Türkçe çevrimdışı konuşma paketi yüklü olmalıdır.

## Model yönetimi

Ebeveyn paneli → Ayarlar → “Ücretsiz cihaz içi yapay zekâ” bölümünden model durumunu görebilir, yeniden indirebilir veya model dosyasını silebilirsiniz.
