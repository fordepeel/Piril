package com.selcukz.piril;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Bundle;
import android.provider.Settings;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.SslErrorHandler;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class MainActivity extends Activity {
    private static final int REQUEST_RECORD_AUDIO = 4107;
    private static final String START_URL = "file:///android_asset/www/index.html";
    private static final String ASSET_PREFIX = "file:///android_asset/www/";

    private WebView webView;
    private SpeechRecognizer speechRecognizer;
    private TextToSpeech textToSpeech;
    private boolean textToSpeechReady;
    private boolean pendingRecognitionStart;
    private boolean recognitionActive;
    private OfflineModelManager offlineModelManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        offlineModelManager = new OfflineModelManager(this, new OfflineModelManager.Listener() {
            @Override
            public void onModelState(String state, int progress, String message) {
                callJs("onModelState", state, progress, message);
            }

            @Override
            public void onResponse(String requestId, boolean ok, String text) {
                callJs("onOfflineResponse", requestId, ok, text);
            }
        });
        configureWebView();
        initializeTextToSpeech();
        hideSystemBars();
        webView.loadUrl(START_URL);
    }

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    private void configureWebView() {
        WebView.setWebContentsDebuggingEnabled(false);
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(255, 248, 237));

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setDefaultTextEncodingName("UTF-8");
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setUserAgentString(settings.getUserAgentString() + " PirilAndroid/1.0.2-Offline");
        settings.setSafeBrowsingEnabled(true);

        webView.addJavascriptInterface(new AndroidBridge(), "PirilAndroid");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String target = uri == null ? "" : uri.toString();
                if (target.startsWith(ASSET_PREFIX)) return false;
                if ("https".equalsIgnoreCase(uri == null ? "" : uri.getScheme())) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
                    catch (ActivityNotFoundException ignored) { }
                }
                return true;
            }

            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                handler.cancel();
            }
        });
        setContentView(webView);
    }

    private void initializeTextToSpeech() {
        textToSpeech = new TextToSpeech(getApplicationContext(), status -> {
            if (status != TextToSpeech.SUCCESS) {
                textToSpeechReady = false;
                return;
            }
            int languageStatus = textToSpeech.setLanguage(new Locale("tr", "TR"));
            textToSpeechReady = languageStatus != TextToSpeech.LANG_MISSING_DATA
                    && languageStatus != TextToSpeech.LANG_NOT_SUPPORTED;
            textToSpeech.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override public void onStart(String utteranceId) { callJs("onSpeechStart"); }
                @Override public void onDone(String utteranceId) {
                    if (utteranceId != null && utteranceId.endsWith("-last")) callJs("onSpeechEnd");
                }
                @Override public void onError(String utteranceId) { callJs("onSpeechError", "Seslendirme tamamlanamadı"); }
            });
            callJs("onTtsReady", textToSpeechReady);
        });
    }

    private void startRecognition() {
        runOnUiThread(() -> {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                pendingRecognitionStart = true;
                requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_RECORD_AUDIO);
                return;
            }
            startRecognitionWithPermission();
        });
    }

    private void startRecognitionWithPermission() {
        pendingRecognitionStart = false;
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            callJs("onRecognitionError", "service-not-allowed");
            return;
        }
        if (speechRecognizer == null) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
            speechRecognizer.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle params) { recognitionActive = true; callJs("onRecognitionStart"); }
                @Override public void onBeginningOfSpeech() { }
                @Override public void onRmsChanged(float rmsdB) { }
                @Override public void onBufferReceived(byte[] buffer) { }
                @Override public void onEndOfSpeech() { recognitionActive = false; callJs("onRecognitionEnd"); }
                @Override public void onError(int error) {
                    recognitionActive = false;
                    callJs("onRecognitionError", mapSpeechError(error));
                    callJs("onRecognitionEnd");
                }
                @Override public void onResults(Bundle results) {
                    recognitionActive = false;
                    ArrayList<String> matches = results == null ? null : results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (matches == null || matches.isEmpty() || matches.get(0).trim().isEmpty()) callJs("onRecognitionError", "no-speech");
                    else callJs("onRecognitionResult", matches.get(0).trim());
                    callJs("onRecognitionEnd");
                }
                @Override public void onPartialResults(Bundle partialResults) { }
                @Override public void onEvent(int eventType, Bundle params) { }
            });
        }

        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR");
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "tr-TR");
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
        intent.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true);
        intent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getPackageName());
        try { speechRecognizer.startListening(intent); }
        catch (RuntimeException error) { callJs("onRecognitionError", "service-not-allowed"); }
    }

    private void stopRecognition() {
        runOnUiThread(() -> {
            if (speechRecognizer != null) {
                try { speechRecognizer.stopListening(); } catch (RuntimeException ignored) { }
            }
        });
    }

    private static String mapSpeechError(int error) {
        switch (error) {
            case SpeechRecognizer.ERROR_AUDIO: return "audio-capture";
            case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS: return "not-allowed";
            case SpeechRecognizer.ERROR_NETWORK:
            case SpeechRecognizer.ERROR_NETWORK_TIMEOUT: return "network";
            case SpeechRecognizer.ERROR_NO_MATCH:
            case SpeechRecognizer.ERROR_SPEECH_TIMEOUT: return "no-speech";
            case SpeechRecognizer.ERROR_RECOGNIZER_BUSY:
            case SpeechRecognizer.ERROR_CLIENT: return "aborted";
            case SpeechRecognizer.ERROR_SERVER:
            case SpeechRecognizer.ERROR_SERVER_DISCONNECTED: return "service-not-allowed";
            case SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED:
            case SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE: return "language-not-supported";
            default: return "unknown";
        }
    }

    private void speak(String text, float rate, float pitch) {
        runOnUiThread(() -> {
            String clean = text == null ? "" : text.trim();
            if (clean.isEmpty()) { callJs("onSpeechEnd"); return; }
            if (!textToSpeechReady || textToSpeech == null) { callJs("onSpeechError", "Türkçe ses verisi bulunamadı"); return; }
            textToSpeech.stop();
            textToSpeech.setLanguage(new Locale("tr", "TR"));
            textToSpeech.setSpeechRate(clamp(rate, 0.55f, 1.45f));
            textToSpeech.setPitch(clamp(pitch, 0.65f, 1.65f));
            List<String> chunks = splitForSpeech(clean, Math.min(3000, TextToSpeech.getMaxSpeechInputLength()));
            String group = "piril-" + System.nanoTime();
            for (int index = 0; index < chunks.size(); index++) {
                boolean first = index == 0;
                boolean last = index == chunks.size() - 1;
                String utteranceId = group + (last ? "-last" : "-" + index);
                textToSpeech.speak(chunks.get(index), first ? TextToSpeech.QUEUE_FLUSH : TextToSpeech.QUEUE_ADD, null, utteranceId);
            }
        });
    }

    private static List<String> splitForSpeech(String text, int maxLength) {
        List<String> result = new ArrayList<>();
        String remaining = text.trim();
        while (remaining.length() > maxLength) {
            int cut = remaining.lastIndexOf('.', maxLength);
            if (cut < maxLength / 2) cut = remaining.lastIndexOf(' ', maxLength);
            if (cut < maxLength / 2) cut = maxLength;
            int end = cut;
            int next = cut;
            if (cut < remaining.length() && remaining.charAt(cut) == '.') { end = cut + 1; next = end; }
            else if (cut < remaining.length() && Character.isWhitespace(remaining.charAt(cut))) next = cut + 1;
            result.add(remaining.substring(0, end).trim());
            remaining = remaining.substring(next).trim();
        }
        if (!remaining.isEmpty()) result.add(remaining);
        return result;
    }

    private static float clamp(float value, float min, float max) { return Math.max(min, Math.min(max, value)); }

    private void callJs(String method, Object... values) {
        if (webView == null) return;
        StringBuilder script = new StringBuilder("window.PirilNative&&window.PirilNative.").append(method).append('(');
        for (int index = 0; index < values.length; index++) {
            if (index > 0) script.append(',');
            Object value = values[index];
            if (value == null) script.append("null");
            else if (value instanceof Boolean || value instanceof Number) script.append(value);
            else script.append(JSONObject.quote(String.valueOf(value)));
        }
        script.append(");");
        String javascript = script.toString();
        runOnUiThread(() -> { if (webView != null) webView.evaluateJavascript(javascript, null); });
    }

    private void openTextToSpeechSettings() {
        runOnUiThread(() -> {
            try { startActivity(new Intent("com.android.settings.TTS_SETTINGS")); }
            catch (ActivityNotFoundException first) {
                try { startActivity(new Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA)); }
                catch (ActivityNotFoundException second) { startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); }
            }
        });
    }

    private void hideSystemBars() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN |
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) { super.onWindowFocusChanged(hasFocus); if (hasFocus) hideSystemBars(); }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQUEST_RECORD_AUDIO) return;
        boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
        if (granted && pendingRecognitionStart) { pendingRecognitionStart = false; startRecognitionWithPermission(); }
        else { pendingRecognitionStart = false; callJs("onRecognitionError", "not-allowed"); }
    }

    @Override protected void onPause() { super.onPause(); stopRecognition(); if (textToSpeech != null) textToSpeech.stop(); }
    @Override protected void onResume() { super.onResume(); hideSystemBars(); }

    @Override
    protected void onDestroy() {
        if (speechRecognizer != null) { speechRecognizer.cancel(); speechRecognizer.destroy(); }
        if (textToSpeech != null) { textToSpeech.stop(); textToSpeech.shutdown(); }
        if (offlineModelManager != null) offlineModelManager.close();
        if (webView != null) { webView.removeJavascriptInterface("PirilAndroid"); webView.destroy(); webView = null; }
        super.onDestroy();
    }

    public final class AndroidBridge {
        @JavascriptInterface public String platform() { return "android"; }
        @JavascriptInterface public void startRecognition() { MainActivity.this.startRecognition(); }
        @JavascriptInterface public void stopRecognition() { MainActivity.this.stopRecognition(); }
        @JavascriptInterface public boolean recognitionAvailable() { return SpeechRecognizer.isRecognitionAvailable(MainActivity.this); }
        @JavascriptInterface public void speak(String text, float rate, float pitch) { MainActivity.this.speak(text, rate, pitch); }
        @JavascriptInterface public void stopSpeaking() { runOnUiThread(() -> { if (textToSpeech != null) textToSpeech.stop(); }); }
        @JavascriptInterface public boolean ttsReady() { return textToSpeechReady; }
        @JavascriptInterface public void openTtsSettings() { openTextToSpeechSettings(); }
        @JavascriptInterface public String offlineModelState() { return offlineModelManager.state(); }
        @JavascriptInterface public long offlineModelBytes() { return offlineModelManager.modelBytes(); }
        @JavascriptInterface public void downloadOfflineModel() { offlineModelManager.download(); }
        @JavascriptInterface public void deleteOfflineModel() { offlineModelManager.deleteModel(); }
        @JavascriptInterface public void requestOffline(String requestId, String prompt) { offlineModelManager.generate(requestId, prompt); }
    }
}
