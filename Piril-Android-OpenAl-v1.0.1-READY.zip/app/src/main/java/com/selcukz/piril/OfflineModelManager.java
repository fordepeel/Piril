package com.selcukz.piril;

import android.content.Context;
import android.os.StatFs;

import com.google.mediapipe.tasks.genai.llminference.LlmInference;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

final class OfflineModelManager {
    interface Listener {
        void onModelState(String state, int progress, String message);
        void onResponse(String requestId, boolean ok, String text);
    }

    private static final String MODEL_URL =
            "https://huggingface.co/litert-community/Qwen2.5-0.5B-Instruct/resolve/main/" +
            "Qwen2.5-0.5B-Instruct_multi-prefill-seq_q8_ekv1280.task?download=true";
    private static final String MODEL_NAME = "qwen2.5-0.5b-instruct-q8.task";
    private static final long MIN_VALID_MODEL_BYTES = 500L * 1024L * 1024L;
    private static final long REQUIRED_FREE_BYTES = 900L * 1024L * 1024L;

    private final Context context;
    private final Listener listener;
    private final ExecutorService ioExecutor = Executors.newSingleThreadExecutor();
    private final Object engineLock = new Object();
    private volatile boolean downloading;
    private volatile LlmInference llm;

    OfflineModelManager(Context context, Listener listener) {
        this.context = context.getApplicationContext();
        this.listener = listener;
    }

    File modelFile() {
        File dir = new File(context.getFilesDir(), "models");
        if (!dir.exists()) dir.mkdirs();
        return new File(dir, MODEL_NAME);
    }

    String state() {
        if (downloading) return "downloading";
        File f = modelFile();
        if (f.isFile() && f.length() >= MIN_VALID_MODEL_BYTES) return "ready";
        return "missing";
    }

    long modelBytes() {
        File f = modelFile();
        return f.isFile() ? f.length() : 0L;
    }

    void download() {
        if (downloading) return;
        if ("ready".equals(state())) {
            listener.onModelState("ready", 100, "Ücretsiz yapay zekâ modeli hazır");
            return;
        }
        downloading = true;
        ioExecutor.execute(() -> {
            File target = modelFile();
            File part = new File(target.getAbsolutePath() + ".part");
            HttpURLConnection connection = null;
            try {
                StatFs stat = new StatFs(context.getFilesDir().getAbsolutePath());
                if (stat.getAvailableBytes() < REQUIRED_FREE_BYTES) {
                    throw new IllegalStateException("NO_SPACE");
                }
                if (part.exists()) part.delete();
                listener.onModelState("downloading", 0, "Model indiriliyor… yaklaşık 550 MB");

                connection = (HttpURLConnection) new URL(MODEL_URL).openConnection();
                connection.setInstanceFollowRedirects(true);
                connection.setConnectTimeout(30_000);
                connection.setReadTimeout(60_000);
                connection.setRequestProperty("User-Agent", "Piril-Android/1.0.2");
                connection.setRequestProperty("Accept", "application/octet-stream");
                int code = connection.getResponseCode();
                if (code < 200 || code >= 300) throw new IllegalStateException("HTTP_" + code);
                long total = connection.getContentLengthLong();

                try (InputStream in = connection.getInputStream(); FileOutputStream out = new FileOutputStream(part)) {
                    byte[] buffer = new byte[256 * 1024];
                    long done = 0L;
                    long lastNotify = 0L;
                    int read;
                    while ((read = in.read(buffer)) != -1) {
                        out.write(buffer, 0, read);
                        done += read;
                        long now = System.currentTimeMillis();
                        if (now - lastNotify >= 450) {
                            int pct = total > 0 ? (int) Math.min(99, (done * 100L) / total) : 0;
                            String mb = (done / (1024L * 1024L)) + " MB" + (total > 0 ? " / " + (total / (1024L * 1024L)) + " MB" : "");
                            listener.onModelState("downloading", pct, mb);
                            lastNotify = now;
                        }
                    }
                    out.getFD().sync();
                }

                if (part.length() < MIN_VALID_MODEL_BYTES) throw new IllegalStateException("MODEL_TOO_SMALL");
                if (target.exists() && !target.delete()) throw new IllegalStateException("OLD_MODEL_DELETE_FAILED");
                if (!part.renameTo(target)) throw new IllegalStateException("MODEL_MOVE_FAILED");
                listener.onModelState("ready", 100, "Model hazır — artık API ücreti yok");
            } catch (Exception e) {
                if (part.exists()) part.delete();
                String msg = "Model indirilemedi. İnternet bağlantısını kontrol edip tekrar deneyin.";
                if ("NO_SPACE".equals(e.getMessage())) msg = "Model için en az 900 MB boş alan gerekiyor.";
                listener.onModelState("error", 0, msg);
            } finally {
                downloading = false;
                if (connection != null) connection.disconnect();
            }
        });
    }

    void deleteModel() {
        ioExecutor.execute(() -> {
            closeEngine();
            File f = modelFile();
            File p = new File(f.getAbsolutePath() + ".part");
            if (f.exists()) f.delete();
            if (p.exists()) p.delete();
            listener.onModelState("missing", 0, "Model silindi");
        });
    }

    void generate(String requestId, String prompt) {
        if (requestId == null || requestId.length() > 100) return;
        if (!"ready".equals(state())) {
            listener.onResponse(requestId, false, "MODEL_MISSING");
            return;
        }
        ioExecutor.execute(() -> {
            try {
                LlmInference engine = ensureEngine();
                String safePrompt = prompt == null ? "" : prompt.trim();
                if (safePrompt.length() > 9000) safePrompt = safePrompt.substring(safePrompt.length() - 9000);
                String result = engine.generateResponse(safePrompt);
                if (result == null || result.trim().isEmpty()) throw new IllegalStateException("EMPTY_RESPONSE");
                listener.onResponse(requestId, true, result.trim());
            } catch (Throwable t) {
                closeEngine();
                listener.onResponse(requestId, false, "INFERENCE_ERROR");
            }
        });
    }

    private LlmInference ensureEngine() {
        synchronized (engineLock) {
            if (llm != null) return llm;
            File file = modelFile();
            LlmInference.LlmInferenceOptions options = LlmInference.LlmInferenceOptions.builder()
                    .setModelPath(file.getAbsolutePath())
                    .setMaxTokens(1280)
                    .setMaxTopK(40)
                    .setPreferredBackend(LlmInference.Backend.CPU)
                    .build();
            llm = LlmInference.createFromOptions(context, options);
            return llm;
        }
    }

    private void closeEngine() {
        synchronized (engineLock) {
            if (llm != null) {
                try { llm.close(); } catch (Throwable ignored) { }
                llm = null;
            }
        }
    }

    void close() {
        closeEngine();
        ioExecutor.shutdownNow();
    }
}
