# Pırıl'ın JavaScript köprüsü küçültme etkinleştirilirse korunmalıdır.
-keepclassmembers class com.selcukz.piril.MainActivity$AndroidBridge {
    @android.webkit.JavascriptInterface <methods>;
}
