# GitHub ile otomatik APK derleme

Bu paket `.github/workflows/build-apk.yml` içerir. Proje GitHub'a `main` veya `master` dalına yüklendiğinde GitHub Actions otomatik olarak Android 35 + Gradle 8.9 ile debug APK üretir.

Üretilen dosya adı: `Piril-v1.0.1-openai-debug.apk`
