# Pırıl v1.0.1 — OpenAI dönüşümü

Bu sürümde Anthropic/Claude entegrasyonu kaldırıldı ve OpenAI Responses API entegrasyonu eklendi.

- API uç noktası: `https://api.openai.com/v1/responses`
- Kimlik doğrulama: `Authorization: Bearer <OPENAI_API_KEY>`
- Model: `gpt-5.6`
- OpenAI API anahtarı Android Keystore ile şifreli saklanır.
- Ebeveyn panelindeki alan artık OpenAI API anahtarı ister (`sk-...`).
- Metin ve çizim/görsel girdileri OpenAI Responses API biçimine dönüştürülür.
- Sürüm: 1.0.1 (`versionCode 2`)

Not: OpenAI API kullanımı ChatGPT aboneliğinden ayrı faturalandırılır. API anahtarını herkese açık istemci uygulamalarına gömmek yerine mümkün olduğunda sunucu tarafında tutmak daha güvenlidir.
