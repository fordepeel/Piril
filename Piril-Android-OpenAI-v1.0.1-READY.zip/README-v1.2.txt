SESLENDIRME STUDYOSU v1.2 - TEZ OKUYUCU

YENILIKLER
- Yalnizca Turkce yerel TTS sesleri listelenir.
- Turkce varsayilan ses en guvenilir secenek olarak sunulur.
- Ses testi basarisiz olan ses uygulama icinde gizlenir; Ayarlar'dan geri getirilebilir.
- Turkce okuma temizleyicisi: zero-width/soft-hyphen karakterleri temizler, satir sonu hecelemelerini ve yanlislikla harf harf ayrilan kelimeleri toparlar.
- "Okundugu Gibi Duzelt" ile secili kelime/ifade icin kalici telaffuz sozlugu olusturulur.
- Telaffuzlar aninda dinlenebilir, duzenlenebilir ve silinebilir.
- Uzun belge parcali okuma, arka plan foreground service, kaldigin yerden devam, bolumler, yer imleri, 30 sn geri/ileri, uyku zamanlayicisi korunur.
- DOCX/TXT/MD/HTML/CSV/JSON/XML yukleme ve M4A ses kaydi korunur.

DERLEME
- Android API 35
- Android Gradle Plugin 8.7.3
- Gradle 8.9
- Java 17
- Surum: 1.2.0 (versionCode 13)
