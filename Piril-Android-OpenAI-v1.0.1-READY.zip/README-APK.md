# Pırıl Android v1.0.2 Offline

Pırıl'ın ücretli API anahtarı istemeyen Android sürümüdür. Uygulama ilk çalıştırmada yaklaşık 550 MB'lık açık kaynak cihaz içi yapay zekâ modelini indirir. Model kurulduktan sonra yapay zekâ cevapları tablette üretilir.

## Özellikler

- API anahtarı yok
- Kullanım başına yapay zekâ ücreti yok
- Qwen2.5-0.5B-Instruct cihaz içi model
- Türkçe çocuk dostu sohbet/hikâye/bilgi modları
- Android TTS ile sesli yanıt
- Android çevrimdışı konuşma tanıma tercihi
- Ebeveyn PIN'i ve kullanım sınırı
- Yerel oyunlar ve kodlama etkinlikleri

## İlk kullanım

APK'yi kurup açın. “Ücretsiz yapay zekâ modeli” penceresinde modeli indirin. İndirme yaklaşık 550 MB'tır. Model tamamlandığında Pırıl ücretli bir API olmadan çalışır.
