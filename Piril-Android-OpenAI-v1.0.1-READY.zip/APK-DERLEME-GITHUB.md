# GitHub Actions ile APK derleme

Bu proje Android Gradle Plugin 8.7.3, Java 17 ve compileSdk 35 kullanır.

Önerilen komut:

```bash
gradle --no-daemon :app:assembleDebug --stacktrace
```

Üretilen APK:

`app/build/outputs/apk/debug/app-debug.apk`

Dağıtım adı:

`Piril-v1.0.2-Offline.apk`
