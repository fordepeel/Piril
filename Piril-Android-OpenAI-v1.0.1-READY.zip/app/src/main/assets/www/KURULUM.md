# Pırıl — Tablete Kurulum Rehberi

Bu klasör, Pırıl uygulamasının tam sürümüdür. Tablete üç şekilde kurulabilir.
**En kolayından en "gerçek uygulama" hissine** doğru sıralanmıştır.

---

## Önce şunu bilin: API anahtarı gerekiyor

Pırıl'ın konuşma ve düşünme kısmı OpenAI modelini kullanır.
Tablete kurulan sürümde bu bağlantı için **kendi API anahtarınız** gerekir.

1. https://platform.openai.com adresine kaydolun
2. **API Keys** bölümünden yeni anahtar oluşturun (`sk-...` ile başlar)
3. **Billing → Limits** kısmından aylık harcama limiti koyun (örn. 10 USD).
   Bunu mutlaka yapın; limitsiz bırakmayın.
4. Uygulamada: **🔒 → PIN (1234) → Ayarlar → OpenAI API anahtarı** → yapıştırın → Kaydet

**Güvenlik notu:** Anahtar tablette saklanır. Kendi çocuklarınızın tabletinde bu
kabul edilebilir bir risk, ama anahtarı başkasına verdiğiniz bir cihaza koymayın
ve uygulamayı herkese açık bir adreste yayınlamayın. Yayınlarsanız anahtarınızı
başkaları da kullanabilir.

API maliyeti seçilen modele ve kullanım miktarına göre değişir. Harcama sınırı
belirleyerek kullanımı kontrol altında tutmanız önerilir.

---

## Yöntem 1 — Ana ekrana ekle (5 dakika, en kolay)

APK'ya gerek yok. Android'de Chrome, PWA'ları gerçek uygulama gibi kurar:
kendi ikonu olur, tam ekran açılır, uygulama listesinde görünür.

1. Bu klasörü bir yere yükleyin (aşağıdaki "Barındırma" bölümüne bakın)
2. Tablette **Chrome** ile adresi açın
3. Sağ üstteki ⋮ menüsü → **Uygulamayı yükle** (veya "Ana ekrana ekle")
4. Ana ekranda Pırıl ikonu belirir, dokununca tam ekran açılır

Sonuç neredeyse APK ile aynıdır. Fark: Play Store'da görünmez ve
başka birine dosya olarak gönderemezsiniz.

---

## Yöntem 2 — Gerçek APK üretmek (20 dakika)

Adım adım:

### a) Klasörü internete yükleyin (ücretsiz)

**GitHub Pages ile:**
1. github.com'da hesap açın → **New repository** → adı `piril`, **Public** seçin
2. **uploading an existing file** → bu klasördeki *tüm* dosyaları sürükleyin
   (index.html, manifest.json, sw.js ve icons klasörü)
3. **Settings → Pages → Source: main / (root) → Save**
4. Birkaç dakika sonra adresiniz hazır: `https://KULLANICIADINIZ.github.io/piril/`

**Netlify ile (daha da hızlı):** app.netlify.com/drop adresine klasörü sürükleyin.

> Not: HTTPS şart. `file://` ile açılan sayfada mikrofon ve kurulum çalışmaz.

### b) PWABuilder ile APK üretin

1. https://www.pwabuilder.com adresine gidin
2. Adresinizi yapıştırın → **Start**
3. **Package for stores → Android → Download package**
4. Ayarlarda:
   - Package ID: `com.soyadiniz.piril` gibi bir şey yazın
   - **Signing key: "Create new"** seçin
   - İnen zip içindeki `signing.keystore` ve şifre dosyasını **saklayın**
     (güncelleme yapacaksanız aynısı gerekir)
5. Zip'in içinden `app-release-signed.apk` dosyasını çıkarın

### c) Tablete kurun

1. APK'yı tablete aktarın (USB, Google Drive veya e-posta)
2. Tablette **Ayarlar → Güvenlik → Bilinmeyen kaynaklar** iznini verin
   (Android 8+ : dosyayı açınca hangi uygulamaya izin vereceğinizi sorar)
3. APK'ya dokunun → Kur

**Uyarı:** PWABuilder'ın ürettiği APK bir "Trusted Web Activity"dir; içeriği
sizin adresinizden çeker. Yani adresi silerseniz uygulama çalışmaz. Ayrıca
TWA'nın adres çubuğunu gizlemesi için `assetlinks.json` doğrulaması gerekir;
PWABuilder bu dosyayı da verir, onu sitenizin `/.well-known/` klasörüne
koymanız gerekir. Koymazsanız uygulama yine çalışır, sadece üstte ince bir
adres çubuğu görünür.

---

## Yöntem 3 — Tamamen çevrimdışı kurulum (ileri seviye)

Kendi bilgisayarınızda Android Studio kurup bir WebView uygulaması
yaparsanız dosyaları APK'nın içine gömebilirsiniz; o zaman barındırmaya
gerek kalmaz. Bu daha uzun bir iştir, isterseniz ayrıca anlatabilirim.

---

## Uygulamada neler var

**Konuşalım:** Sohbet · Hikaye (çocuk seçim yaparak yönlendirir) · Uyku Masalı · Duygu Köşesi
**Öğrenelim:** Bilgi Küpü · İngilizce · Deney Köşesi
**Oynayalım:** Sayı Oyunu · Bilmece · Rol Yapma · Çiz & Anlat
**Zeka Oyunları:** Satranç · Hafıza · Örüntü · Mini Sudoku
**Kodlama Yolu:** 12 görevlik hikayeli macera

### Satranç hakkında
Tam kurallı gerçek bir satranç motoru (rok, geçerken alma, terfi dahil). Dört zorluk
seviyesi var; "Çok Kolay" acemi çocuklar için. **🎓 Taşları Öğren** düğmesine basıp bir
taşa dokunursa, o taşın nasıl gittiğini görsel olarak gösterir ve çocuk diliyle anlatır.
💡 tuşu Pırıl'dan ipucu ister — cevabı söylemez, düşündürür.

### Kodlama Yolu hakkında
Çocuk, Pırıl'a komut vererek onu yıldızlara ulaştırır. Dört bölüm, hikaye ile ilerler:

| Bölüm | Öğrettiği | Gerçek programlama karşılığı |
|---|---|---|
| 1. Sıra | Komutlar yazdığın sırayla çalışır | sequence |
| 2. Tekrar | Aynı işi tekrarlatmak | for döngüsü |
| 3. Eğer | Duruma göre karar vermek | if koşulu |
| 4. Beceri | Kendi komutunu tanımlamak | function |

Her görev bitince **💻 Gerçek Kod** perdesi açılır ve çocuğun kurduğu blokların
gerçek kodda nasıl yazıldığını gösterir. Böylece blok mantığından yazılı koda
doğal bir geçiş olur. İlerleme kaydedilir; ebeveyn panelinde "KOD GÖREVİ 5/12"
gibi görünür.

Takıldığında 💡 tuşuna basar; Pırıl cevabı söylemez, ipucu verip soru sorar.

---

## Tabletde yapılması önerilen ayarlar

| Ayar | Nerede | Neden |
|---|---|---|
| Mikrofon izni | Chrome sorunca "İzin ver" | Konuşma tanıma için şart |
| Türkçe TTS sesi | Ayarlar → Erişilebilirlik → Metin okuma → Google TTS → Türkçe indir | Sesin doğal olması için |
| Ekran kilidi süresi | Ayarlar → Ekran | Hikaye dinlerken ekran kapanmasın |
| Ebeveyn PIN'i | Pırıl → 🔒 → Ayarlar | Varsayılan 1234, mutlaka değiştirin |

---

## Uygulama içi ebeveyn kontrolleri

- **PIN korumalı panel** (varsayılan `1234`)
- **Günlük süre sınırı** — dolunca uygulama kilitlenir
- **15 dakikada bir göz molası**
- **Aktivite kilitleme** — istemediğiniz modları kapatın
- **Konuşma kayıtları** — çocuğun ne sorduğunu, Pırıl'ın ne dediğini görürsünüz
- **⚠️ işaretli kayıtlar** — çocuk üzücü/kaygı verici bir şey anlattıysa
  uygulama araya girip "bir yetişkine anlat" der ve kaydı işaretler
- **Ses ayarları** — hız, ton, ses seçimi

---

## Sorun giderme

**Mikrofon çalışmıyor** → Adres `https://` ile mi başlıyor? Chrome kullanıyor
musunuz? Samsung Internet ve Firefox'ta konuşma tanıma sınırlıdır.

**Ses çıkmıyor / robot gibi** → Tablete Google Türkçe TTS sesini indirin,
sonra Pırıl → Ayarlar → Ses seçimi'nden seçin.

**"API anahtarı gerekli" diyor** → Ebeveyn paneline anahtarı girmemişsiniz
ya da anahtar geçersiz/limiti dolmuş. platform.openai.com'dan kontrol edin.

**Kurulum seçeneği çıkmıyor** → manifest.json ve sw.js dosyaları
index.html ile aynı klasörde mi? Adres HTTPS mi?

**Çocuk PIN'i buldu** → Ayarlar'dan değiştirin; doğum günü gibi tahmin
edilebilir bir sayı seçmeyin.
