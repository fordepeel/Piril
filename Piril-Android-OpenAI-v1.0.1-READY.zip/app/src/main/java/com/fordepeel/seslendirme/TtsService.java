package com.fordepeel.seslendirme;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;

import java.io.File;
import java.io.FileInputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

public class TtsService extends Service {
    public static final String ACTION_START = "com.fordepeel.seslendirme.START";
    public static final String ACTION_PAUSE = "com.fordepeel.seslendirme.PAUSE";
    public static final String ACTION_RESUME = "com.fordepeel.seslendirme.RESUME";
    public static final String ACTION_STOP = "com.fordepeel.seslendirme.STOP";
    public static final String ACTION_SEEK = "com.fordepeel.seslendirme.SEEK";
    public static final String ACTION_BACK = "com.fordepeel.seslendirme.BACK";
    public static final String ACTION_FORWARD = "com.fordepeel.seslendirme.FORWARD";
    public static final String ACTION_TIMER = "com.fordepeel.seslendirme.TIMER";
    public static final String ACTION_STATUS = "com.fordepeel.seslendirme.STATUS";

    public static final String PREFS = "tts_reader_v11";
    private static final String CHANNEL_ID = "tez_okuyucu";
    private static final int NOTIFICATION_ID = 911;

    private TextToSpeech tts;
    private boolean ttsReady = false;
    private boolean playing = false;
    private boolean paused = false;
    private boolean retryingWithFallback = false;
    private String fullText = "";
    private String docHash = "";
    private String docName = "Belge";
    private String voiceName = "";
    private float rate = 1f;
    private float pitch = 1f;
    private float volume = 1f;
    private int currentPos = 0;
    private int chunkStart = 0;
    private int chunkEnd = 0;
    private String activeUtteranceId = "";
    private int paragraphPauseMs = 250;
    private long sleepUntil = 0L;
    private long lastPersistAt = 0L;
    private long lastNotifyAt = 0L;
    private PowerManager.WakeLock wakeLock;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable sleepCheck = new Runnable() {
        @Override public void run() {
            if (sleepUntil > 0 && System.currentTimeMillis() >= sleepUntil) {
                pauseInternal("Uyku zamanlayıcısı doldu");
                sleepUntil = 0L;
                persistState(true);
                sendStatus("paused", "Uyku zamanlayıcısı doldu");
                updateNotification(true);
                return;
            }
            handler.postDelayed(this, 1000L);
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        initTts();
        handler.post(sleepCheck);
    }

    private void initTts() {
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                ttsReady = true;
                tts.setLanguage(new Locale("tr", "TR"));
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override public void onStart(String utteranceId) {
                        if (!utteranceId.equals(activeUtteranceId)) return;
                        playing = true;
                        paused = false;
                        sendStatus("playing", "");
                    }

                    @Override public void onDone(String utteranceId) {
                        if (!utteranceId.equals(activeUtteranceId) || paused) return;
                        currentPos = Math.max(currentPos, chunkEnd);
                        persistState(true);
                        retryingWithFallback = false;
                        if (currentPos >= fullText.length()) {
                            playing = false;
                            paused = false;
                            currentPos = fullText.length();
                            persistState(true);
                            sendStatus("done", "Belge tamamlandı");
                            stopForeground(STOP_FOREGROUND_REMOVE);
                            releaseWakeLock();
                            stopSelf();
                        } else {
                            handler.postDelayed(() -> playNextChunk(), Math.max(0, paragraphPauseMs));
                        }
                    }

                    @Override public void onError(String utteranceId) {
                        handleTtsError(utteranceId);
                    }

                    @Override public void onError(String utteranceId, int errorCode) {
                        handleTtsError(utteranceId);
                    }

                    @Override public void onRangeStart(String utteranceId, int start, int end, int frame) {
                        if (!utteranceId.equals(activeUtteranceId)) return;
                        currentPos = clamp(chunkStart + Math.max(0, start), 0, fullText.length());
                        long now = System.currentTimeMillis();
                        if (now - lastPersistAt > 1200L) {
                            persistState(false);
                            sendStatus("playing", "");
                            lastPersistAt = now;
                        }
                        if (now - lastNotifyAt > 5000L) {
                            updateNotification(false);
                            lastNotifyAt = now;
                        }
                    }
                });
                if (playing && !paused && !fullText.isEmpty()) playNextChunk();
            } else {
                sendStatus("error", "Android ses motoru başlatılamadı");
            }
        });
    }

    private void handleTtsError(String utteranceId) {
        if (!utteranceId.equals(activeUtteranceId) || paused) return;
        if (!retryingWithFallback && chooseAlternativeTurkishVoice(voiceName)) {
            retryingWithFallback = true;
            currentPos = chunkStart;
            sendStatus("playing", "Seçilen ses çalışmadı; başka bir Türkçe sese geçildi");
            handler.postDelayed(this::playNextChunk, 250L);
            return;
        }
        playing = false;
        paused = true;
        persistState(true);
        sendStatus("error", "Türkçe ses motoru bu bölümü okuyamadı. Sesi Test Et ile başka bir ses deneyin.");
        updateNotification(true);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_STICKY;
        String action = intent.getAction();
        if (ACTION_START.equals(action)) {
            handleStart(intent);
        } else if (ACTION_PAUSE.equals(action)) {
            pauseInternal("Duraklatıldı");
        } else if (ACTION_RESUME.equals(action)) {
            resumeInternal();
        } else if (ACTION_STOP.equals(action)) {
            stopInternal(true);
        } else if (ACTION_SEEK.equals(action)) {
            seekInternal(intent.getIntExtra("position", currentPos));
        } else if (ACTION_BACK.equals(action)) {
            seekInternal(currentPos - estimateCharsForSeconds(30));
        } else if (ACTION_FORWARD.equals(action)) {
            seekInternal(currentPos + estimateCharsForSeconds(30));
        } else if (ACTION_TIMER.equals(action)) {
            int minutes = intent.getIntExtra("minutes", 0);
            sleepUntil = minutes > 0 ? System.currentTimeMillis() + minutes * 60_000L : 0L;
            persistState(true);
            sendStatus(playing ? "playing" : (paused ? "paused" : "idle"), minutes > 0 ? (minutes + " dk uyku zamanlayıcısı") : "Uyku zamanlayıcısı kapalı");
            updateNotification(false);
        }
        return START_STICKY;
    }

    private void handleStart(Intent intent) {
        try {
            String path = intent.getStringExtra("textPath");
            if (path == null) throw new Exception("Metin yolu yok");
            File f = new File(path);
            fullText = readFileUtf8(f);
            docHash = safe(intent.getStringExtra("docHash"));
            docName = safe(intent.getStringExtra("docName"));
            if (docName.isEmpty()) docName = "Belge";
            voiceName = safe(intent.getStringExtra("voiceName"));
            rate = intent.getFloatExtra("rate", 1f);
            pitch = intent.getFloatExtra("pitch", 1f);
            volume = intent.getFloatExtra("volume", 1f);
            paragraphPauseMs = clamp(intent.getIntExtra("paragraphPauseMs", 250), 0, 1500);
            currentPos = clamp(intent.getIntExtra("startPos", 0), 0, fullText.length());
            sleepUntil = 0L;
            paused = false;
            playing = true;
            retryingWithFallback = false;
            acquireWakeLock();
            startForeground(NOTIFICATION_ID, buildNotification());
            persistState(true);
            if (ttsReady) playNextChunk();
        } catch (Exception e) {
            playing = false;
            paused = false;
            sendStatus("error", "Belge başlatılamadı: " + e.getMessage());
            stopSelf();
        }
    }

    private void playNextChunk() {
        if (!ttsReady || paused || !playing || fullText.isEmpty()) return;
        if (currentPos >= fullText.length()) {
            sendStatus("done", "Belge tamamlandı");
            return;
        }
        int maxSpeech = Math.max(1200, TextToSpeech.getMaxSpeechInputLength() - 300);
        int preferred = Math.min(3200, maxSpeech);
        chunkStart = clamp(currentPos, 0, fullText.length());
        chunkEnd = findNaturalEnd(fullText, chunkStart, preferred);
        if (chunkEnd <= chunkStart) chunkEnd = Math.min(fullText.length(), chunkStart + preferred);
        String chunk = fullText.substring(chunkStart, chunkEnd);
        activeUtteranceId = UUID.randomUUID().toString();
        configureVoice();
        tts.setSpeechRate(Math.max(0.1f, Math.min(2.5f, rate)));
        tts.setPitch(Math.max(0.5f, Math.min(2f, pitch)));
        Bundle params = new Bundle();
        params.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, Math.max(0f, Math.min(1f, volume)));
        int result = tts.speak(chunk, TextToSpeech.QUEUE_FLUSH, params, activeUtteranceId);
        if (result == TextToSpeech.ERROR) handleTtsError(activeUtteranceId);
    }

    private int findNaturalEnd(String text, int start, int maxLen) {
        int hard = Math.min(text.length(), start + maxLen);
        if (hard >= text.length()) return text.length();
        int min = Math.min(hard, start + (int)(maxLen * 0.58));
        int best = -1;
        for (int i = hard - 1; i >= min; i--) {
            char c = text.charAt(i);
            if (c == '\n' && i > start && text.charAt(i - 1) == '\n') { best = i + 1; break; }
        }
        if (best < 0) {
            for (int i = hard - 1; i >= min; i--) {
                char c = text.charAt(i);
                if (c == '.' || c == '!' || c == '?' || c == ';' || c == ':') { best = i + 1; break; }
            }
        }
        if (best < 0) {
            for (int i = hard - 1; i >= min; i--) {
                if (Character.isWhitespace(text.charAt(i))) { best = i + 1; break; }
            }
        }
        return best > start ? best : hard;
    }

    private void configureVoice() {
        if (tts == null || !ttsReady) return;
        if (voiceName.isEmpty()) {
            tts.setLanguage(new Locale("tr", "TR"));
            return;
        }
        Set<Voice> voices = tts.getVoices();
        if (voices != null) {
            for (Voice v : voices) {
                Locale l = v.getLocale();
                boolean validTurkishLocal = l != null
                        && "tr".equalsIgnoreCase(l.getLanguage())
                        && !v.isNetworkConnectionRequired();
                if (validTurkishLocal && voiceName.equals(v.getName())) {
                    tts.setVoice(v);
                    return;
                }
            }
        }
        voiceName = "";
        tts.setLanguage(new Locale("tr", "TR"));
    }

    private boolean chooseAlternativeTurkishVoice(String excludedName) {
        if (tts == null) return false;
        Set<Voice> voices = tts.getVoices();
        if (voices != null) {
            for (Voice v : voices) {
                Locale l = v.getLocale();
                boolean validTurkishLocal = l != null
                        && "tr".equalsIgnoreCase(l.getLanguage())
                        && !v.isNetworkConnectionRequired();
                if (!validTurkishLocal) continue;
                if (excludedName != null && excludedName.equals(v.getName())) continue;
                voiceName = v.getName();
                tts.setVoice(v);
                return true;
            }
        }
        if (excludedName != null && !excludedName.isEmpty()) {
            voiceName = "";
            return tts.setLanguage(new Locale("tr", "TR")) >= TextToSpeech.LANG_AVAILABLE;
        }
        return false;
    }

    private void pauseInternal(String message) {
        if (tts != null) tts.stop();
        paused = true;
        playing = false;
        persistState(true);
        releaseWakeLock();
        sendStatus("paused", message);
        updateNotification(true);
    }

    private void resumeInternal() {
        if (fullText.isEmpty()) {
            restoreTextFromPrefs();
        }
        if (fullText.isEmpty()) {
            sendStatus("error", "Devam edilecek belge bulunamadı");
            return;
        }
        paused = false;
        playing = true;
        acquireWakeLock();
        startForeground(NOTIFICATION_ID, buildNotification());
        if (ttsReady) playNextChunk();
        sendStatus("playing", "Devam ediyor");
    }

    private void stopInternal(boolean userStop) {
        if (tts != null) tts.stop();
        playing = false;
        paused = false;
        persistState(true);
        releaseWakeLock();
        sendStatus("stopped", userStop ? "Durduruldu" : "");
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    private void seekInternal(int target) {
        if (fullText.isEmpty()) restoreTextFromPrefs();
        currentPos = clamp(target, 0, fullText.length());
        if (tts != null) tts.stop();
        persistState(true);
        sendStatus(playing ? "playing" : "paused", "");
        if (playing && !paused && ttsReady) handler.postDelayed(this::playNextChunk, 150L);
        updateNotification(false);
    }

    private void restoreTextFromPrefs() {
        try {
            SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
            String path = p.getString("active_path", "");
            if (!path.isEmpty() && new File(path).exists()) {
                fullText = readFileUtf8(new File(path));
                docHash = p.getString("active_hash", "");
                docName = p.getString("active_name", "Belge");
                currentPos = clamp(p.getInt("active_pos", 0), 0, fullText.length());
                voiceName = p.getString("active_voice", "");
                rate = p.getFloat("active_rate", 1f);
                pitch = p.getFloat("active_pitch", 1f);
                volume = p.getFloat("active_volume", 1f);
                paragraphPauseMs = p.getInt("active_pause_ms", 250);
            }
        } catch (Exception ignored) { }
    }

    private void persistState(boolean force) {
        if (docHash.isEmpty()) return;
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        SharedPreferences.Editor e = p.edit()
                .putString("active_hash", docHash)
                .putString("active_name", docName)
                .putInt("active_pos", currentPos)
                .putInt("active_len", fullText.length())
                .putBoolean("active_playing", playing)
                .putBoolean("active_paused", paused)
                .putString("active_voice", voiceName)
                .putFloat("active_rate", rate)
                .putFloat("active_pitch", pitch)
                .putFloat("active_volume", volume)
                .putInt("active_pause_ms", paragraphPauseMs)
                .putLong("sleep_until", sleepUntil)
                .putInt("pos_" + docHash, currentPos)
                .putInt("len_" + docHash, fullText.length())
                .putString("name_" + docHash, docName);
        e.apply();
    }

    private static String readFileUtf8(File file) throws Exception {
        try (FileInputStream in = new FileInputStream(file); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int n;
            while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
            return new String(out.toByteArray(), StandardCharsets.UTF_8);
        }
    }

    public static String hashText(String text) {
        try {
            MessageDigest d = MessageDigest.getInstance("SHA-256");
            byte[] b = d.digest((text == null ? "" : text).getBytes(StandardCharsets.UTF_8));
            StringBuilder s = new StringBuilder();
            for (int i = 0; i < 12 && i < b.length; i++) s.append(String.format(Locale.ROOT, "%02x", b[i]));
            return s.toString();
        } catch (Exception e) {
            return Integer.toHexString((text == null ? "" : text).hashCode());
        }
    }

    private void sendStatus(String state, String message) {
        Intent i = new Intent(ACTION_STATUS);
        i.setPackage(getPackageName());
        i.putExtra("state", state);
        i.putExtra("message", message == null ? "" : message);
        i.putExtra("position", currentPos);
        i.putExtra("length", fullText.length());
        i.putExtra("docHash", docHash);
        i.putExtra("docName", docName);
        i.putExtra("voiceName", voiceName);
        i.putExtra("sleepUntil", sleepUntil);
        sendBroadcast(i);
    }

    private void createChannel() {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "Tez Okuyucu", NotificationManager.IMPORTANCE_LOW);
        ch.setDescription("Arka planda belge seslendirme kontrolleri");
        ch.setSound(null, null);
        nm.createNotificationChannel(ch);
    }

    private Notification buildNotification() {
        Intent open = new Intent(this, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent content = PendingIntent.getActivity(this, 10, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        PendingIntent back = servicePending(ACTION_BACK, 11);
        PendingIntent playPause = servicePending(paused ? ACTION_RESUME : ACTION_PAUSE, 12);
        PendingIntent forward = servicePending(ACTION_FORWARD, 13);
        PendingIntent stop = servicePending(ACTION_STOP, 14);
        int pct = fullText.isEmpty() ? 0 : Math.round((currentPos * 100f) / fullText.length());
        String sub = pct + "% · " + (paused ? "Duraklatıldı" : "Okunuyor");
        if (sleepUntil > 0) {
            long mins = Math.max(0, (sleepUntil - System.currentTimeMillis() + 59_999L) / 60_000L);
            sub += " · ⏲ " + mins + " dk";
        }
        return new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle(docName)
                .setContentText(sub)
                .setOnlyAlertOnce(true)
                .setOngoing(playing || paused)
                .setContentIntent(content)
                .addAction(new Notification.Action.Builder(android.R.drawable.ic_media_rew, "30 sn geri", back).build())
                .addAction(new Notification.Action.Builder(paused ? android.R.drawable.ic_media_play : android.R.drawable.ic_media_pause, paused ? "Devam" : "Duraklat", playPause).build())
                .addAction(new Notification.Action.Builder(android.R.drawable.ic_media_ff, "30 sn ileri", forward).build())
                .addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel, "Durdur", stop).build())
                .build();
    }

    private PendingIntent servicePending(String action, int requestCode) {
        Intent i = new Intent(this, TtsService.class).setAction(action);
        return PendingIntent.getService(this, requestCode, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private void updateNotification(boolean force) {
        if (!force && !(playing || paused)) return;
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        nm.notify(NOTIFICATION_ID, buildNotification());
    }

    private void acquireWakeLock() {
        if (wakeLock != null && wakeLock.isHeld()) return;
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Seslendirme:TezOkuyucu");
        wakeLock.setReferenceCounted(false);
        try { wakeLock.acquire(12 * 60 * 60 * 1000L); } catch (Exception ignored) { }
    }

    private void releaseWakeLock() {
        try { if (wakeLock != null && wakeLock.isHeld()) wakeLock.release(); } catch (Exception ignored) { }
    }

    private int estimateCharsForSeconds(int seconds) {
        float charsPerSecond = 13.0f * Math.max(0.5f, rate);
        return Math.max(300, Math.round(charsPerSecond * seconds));
    }

    private static int clamp(int v, int min, int max) { return Math.max(min, Math.min(max, v)); }
    private static String safe(String s) { return s == null ? "" : s; }

    @Override public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        try { if (tts != null) { tts.stop(); tts.shutdown(); } } catch (Exception ignored) { }
        releaseWakeLock();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
