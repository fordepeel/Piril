package com.fordepeel.seslendirme;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.OpenableColumns;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import android.text.Html;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class MainActivity extends Activity {
    private static final int REQ_AUDIO = 301;
    private static final int REQ_PICK_TEXT = 401;
    private static final int REQ_EXPORT_AUDIO = 402;

    private WebView webView;
    private TextToSpeech tts;
    private volatile boolean ttsReady = false;
    private volatile boolean ttsPaused = false;
    private String ttsFullText = "";
    private String ttsVoiceName = "";
    private float ttsRate = 1f;
    private float ttsPitch = 1f;
    private float ttsVolume = 1f;
    private int ttsResumeIndex = 0;
    private int ttsBaseOffset = 0;
    private String activeUtteranceId = "";

    private MediaRecorder recorder;
    private boolean recording = false;
    private long recordingStartedAt = 0L;
    private File recordingFile;
    private String recordingId;
    private final Map<String, File> recordings = new HashMap<>();
    private File pendingExportFile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new TTSBridge(), "AndroidTTS");
        webView.addJavascriptInterface(new RecorderBridge(), "AndroidRecorder");
        webView.addJavascriptInterface(new FilesBridge(), "AndroidFiles");
        webView.loadUrl("file:///android_asset/index.html");

        initTts();
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
        }
    }

    private void initTts() {
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                ttsReady = true;
                tts.setLanguage(new Locale("tr", "TR"));
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override public void onStart(String utteranceId) { }

                    @Override
                    public void onDone(String utteranceId) {
                        if (!utteranceId.equals(activeUtteranceId) || ttsPaused) return;
                        runJs("window.__nativeTtsDone && window.__nativeTtsDone()");
                    }

                    @Override
                    public void onError(String utteranceId) {
                        if (!utteranceId.equals(activeUtteranceId) || ttsPaused) return;
                        runJs("window.__nativeTtsError && window.__nativeTtsError()");
                    }

                    @Override
                    public void onRangeStart(String utteranceId, int start, int end, int frame) {
                        if (!utteranceId.equals(activeUtteranceId)) return;
                        final int absStart = ttsBaseOffset + start;
                        final int absEnd = ttsBaseOffset + end;
                        ttsResumeIndex = absStart;
                        runJs("window.__nativeTtsBoundary && window.__nativeTtsBoundary(" + absStart + "," + absEnd + ")");
                    }
                });
                runJs("window.onNativeTtsReady && window.onNativeTtsReady()");
            }
        });
    }

    private void configureVoice(String voiceName) {
        if (!ttsReady || voiceName == null || voiceName.isEmpty()) return;
        Set<Voice> voices = tts.getVoices();
        if (voices == null) return;
        for (Voice v : voices) {
            if (voiceName.equals(v.getName())) {
                tts.setVoice(v);
                return;
            }
        }
    }

    private void speakSegment(String text, int baseOffset) {
        if (!ttsReady || text == null || text.isEmpty()) return;
        ttsBaseOffset = baseOffset;
        activeUtteranceId = UUID.randomUUID().toString();
        configureVoice(ttsVoiceName);
        tts.setSpeechRate(Math.max(0.1f, ttsRate));
        tts.setPitch(Math.max(0.1f, ttsPitch));
        Bundle params = new Bundle();
        params.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, Math.max(0f, Math.min(1f, ttsVolume)));
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, params, activeUtteranceId);
    }

    private void runJs(String js) {
        if (webView == null) return;
        webView.post(() -> webView.evaluateJavascript(js, null));
    }

    public class TTSBridge {
        @JavascriptInterface
        public String getVoices() {
            JSONArray arr = new JSONArray();
            try {
                if (ttsReady && tts.getVoices() != null) {
                    for (Voice v : tts.getVoices()) {
                        JSONObject o = new JSONObject();
                        o.put("name", v.getName());
                        o.put("lang", v.getLocale() != null ? v.getLocale().toLanguageTag() : "tr-TR");
                        arr.put(o);
                    }
                }
            } catch (Exception ignored) { }
            return arr.toString();
        }

        @JavascriptInterface
        public boolean isReady() { return ttsReady; }

        @JavascriptInterface
        public void speak(String text, String voiceName, float rate, float pitch, float volume) {
            runOnUiThread(() -> {
                if (!ttsReady) {
                    runJs("window.__nativeTtsError && window.__nativeTtsError()");
                    return;
                }
                ttsFullText = text == null ? "" : text;
                ttsVoiceName = voiceName == null ? "" : voiceName;
                ttsRate = rate;
                ttsPitch = pitch;
                ttsVolume = volume;
                ttsResumeIndex = 0;
                ttsPaused = false;
                speakSegment(ttsFullText, 0);
            });
        }

        @JavascriptInterface
        public void pause() {
            runOnUiThread(() -> {
                if (!ttsReady) return;
                ttsPaused = true;
                tts.stop();
            });
        }

        @JavascriptInterface
        public void resume() {
            runOnUiThread(() -> {
                if (!ttsReady || !ttsPaused) return;
                ttsPaused = false;
                int start = Math.max(0, Math.min(ttsResumeIndex, ttsFullText.length()));
                speakSegment(ttsFullText.substring(start), start);
            });
        }

        @JavascriptInterface
        public void stop() {
            runOnUiThread(() -> {
                ttsPaused = false;
                ttsResumeIndex = 0;
                if (tts != null) tts.stop();
            });
        }
    }

    public class RecorderBridge {
        @JavascriptInterface
        public boolean hasPermission() {
            return checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
        }

        @JavascriptInterface
        public void requestPermission() {
            runOnUiThread(() -> requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO));
        }

        @JavascriptInterface
        public synchronized boolean startRecording() {
            if (recording) return true;
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                requestPermission();
                return false;
            }
            try {
                File dir = new File(getExternalFilesDir(Environment.DIRECTORY_MUSIC), "SeslendirmeKayitlari");
                if (!dir.exists()) dir.mkdirs();
                recordingId = "take-" + System.currentTimeMillis();
                recordingFile = new File(dir, recordingId + ".m4a");
                recorder = new MediaRecorder();
                recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
                recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
                recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
                recorder.setAudioEncodingBitRate(128000);
                recorder.setAudioSamplingRate(44100);
                recorder.setOutputFile(recordingFile.getAbsolutePath());
                recorder.prepare();
                recorder.start();
                recordingStartedAt = System.currentTimeMillis();
                recording = true;
                return true;
            } catch (Exception e) {
                safeReleaseRecorder();
                return false;
            }
        }

        @JavascriptInterface
        public synchronized int getAmplitude() {
            if (!recording || recorder == null) return 0;
            try {
                int amp = recorder.getMaxAmplitude();
                double normalized = Math.min(1.0, amp / 32767.0);
                return (int)Math.round(Math.sqrt(normalized) * 100.0);
            } catch (Exception e) {
                return 0;
            }
        }

        @JavascriptInterface
        public synchronized String stopRecording() {
            JSONObject out = new JSONObject();
            if (!recording || recorder == null) {
                try { out.put("ok", false); out.put("error", "Kayıt aktif değil"); } catch (Exception ignored) { }
                return out.toString();
            }
            try {
                recorder.stop();
                long durationMs = Math.max(0L, System.currentTimeMillis() - recordingStartedAt);
                safeReleaseRecorder();
                recording = false;
                recordings.put(recordingId, recordingFile);
                out.put("ok", true);
                out.put("id", recordingId);
                out.put("duration", durationMs / 1000.0);
                out.put("sizeKB", Math.max(1L, recordingFile.length() / 1024L));
                out.put("name", "Kayıt " + recordings.size());
                return out.toString();
            } catch (Exception e) {
                try {
                    safeReleaseRecorder();
                    recording = false;
                    if (recordingFile != null) recordingFile.delete();
                    out.put("ok", false);
                    out.put("error", "Kayıt çok kısa veya tamamlanamadı");
                } catch (Exception ignored) { }
                return out.toString();
            }
        }

        @JavascriptInterface
        public void play(String id) {
            File f = recordings.get(id);
            if (f == null || !f.exists()) return;
            runOnUiThread(() -> {
                try {
                    MediaPlayer player = new MediaPlayer();
                    player.setDataSource(f.getAbsolutePath());
                    player.setOnPreparedListener(MediaPlayer::start);
                    player.setOnCompletionListener(mp -> { mp.release(); runJs("window.__nativePlaybackEnded && window.__nativePlaybackEnded(" + JSONObject.quote(id) + ")"); });
                    player.setOnErrorListener((mp, what, extra) -> { mp.release(); return true; });
                    player.prepareAsync();
                } catch (Exception ignored) { }
            });
        }

        @JavascriptInterface
        public void export(String id, String fileName) {
            File f = recordings.get(id);
            if (f == null || !f.exists()) return;
            pendingExportFile = f;
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("audio/mp4");
                i.putExtra(Intent.EXTRA_TITLE, (fileName == null || fileName.isEmpty()) ? "ses-kaydi.m4a" : fileName);
                startActivityForResult(i, REQ_EXPORT_AUDIO);
            });
        }

        @JavascriptInterface
        public synchronized void delete(String id) {
            File f = recordings.remove(id);
            if (f != null && f.exists()) f.delete();
        }
    }

    private synchronized void safeReleaseRecorder() {
        try { if (recorder != null) recorder.reset(); } catch (Exception ignored) { }
        try { if (recorder != null) recorder.release(); } catch (Exception ignored) { }
        recorder = null;
    }

    public class FilesBridge {
        @JavascriptInterface
        public void pickTextFile() {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                        "text/plain", "text/markdown", "text/html", "text/csv", "application/json",
                        "application/xml", "text/xml",
                        "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                });
                startActivityForResult(i, REQ_PICK_TEXT);
            });
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();

        if (requestCode == REQ_PICK_TEXT) {
            try {
                String name = getDisplayName(uri);
                String text = name.toLowerCase(Locale.ROOT).endsWith(".docx") ? readDocx(uri) : readUtf8Text(uri);
                if (text.length() > 2_000_000) text = text.substring(0, 2_000_000);
                String js = "window.onNativeFileLoaded && window.onNativeFileLoaded(" + JSONObject.quote(name) + "," + JSONObject.quote(text) + ")";
                runJs(js);
            } catch (Exception e) {
                Toast.makeText(this, "Dosya okunamadı: " + e.getMessage(), Toast.LENGTH_LONG).show();
                runJs("window.onNativeFileError && window.onNativeFileError()");
            }
        } else if (requestCode == REQ_EXPORT_AUDIO && pendingExportFile != null) {
            try (InputStream in = new FileInputStream(pendingExportFile); OutputStream out = getContentResolver().openOutputStream(uri)) {
                if (out == null) throw new Exception("Hedef açılamadı");
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                Toast.makeText(this, "Kayıt kaydedildi", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "Kayıt kaydedilemedi", Toast.LENGTH_LONG).show();
            } finally {
                pendingExportFile = null;
            }
        }
    }

    private String getDisplayName(Uri uri) {
        String name = "metin.txt";
        try (Cursor c = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) name = c.getString(0);
        } catch (Exception ignored) { }
        return name == null ? "metin.txt" : name;
    }

    private String readUtf8Text(Uri uri) throws Exception {
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            if (in == null) throw new Exception("Dosya açılamadı");
            byte[] bytes = readAll(in);
            String s = new String(bytes, StandardCharsets.UTF_8);
            if (s.startsWith("\uFEFF")) s = s.substring(1);
            return s;
        }
    }

    private String readDocx(Uri uri) throws Exception {
        try (InputStream raw = getContentResolver().openInputStream(uri); ZipInputStream zip = new ZipInputStream(raw)) {
            ZipEntry entry;
            while ((entry = zip.getNextEntry()) != null) {
                if ("word/document.xml".equals(entry.getName())) {
                    String xml = new String(readAll(zip), StandardCharsets.UTF_8);
                    String text = xml
                            .replaceAll("(?i)</w:p>", "\n")
                            .replaceAll("(?i)<w:tab[^>]*/>", "\t")
                            .replaceAll("(?i)<w:br[^>]*/>", "\n")
                            .replaceAll("<[^>]+>", "");
                    return Html.fromHtml(text, Html.FROM_HTML_MODE_LEGACY).toString().replaceAll("\n{3,}", "\n\n").trim();
                }
            }
        }
        throw new Exception("DOCX metni bulunamadı");
    }

    private byte[] readAll(InputStream in) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        return out.toByteArray();
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        if (recording) {
            try { recorder.stop(); } catch (Exception ignored) { }
            safeReleaseRecorder();
        }
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
