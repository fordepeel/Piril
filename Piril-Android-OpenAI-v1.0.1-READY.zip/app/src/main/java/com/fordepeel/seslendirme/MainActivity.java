package com.fordepeel.seslendirme;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.OpenableColumns;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import android.text.Html;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class MainActivity extends Activity {
    private static final int REQ_AUDIO = 301;
    private static final int REQ_PICK_TEXT = 401;
    private static final int REQ_EXPORT_AUDIO = 402;
    private static final int REQ_NOTIFICATIONS = 403;

    private WebView webView;
    private TextToSpeech previewTts;
    private volatile boolean previewTtsReady = false;

    private MediaRecorder recorder;
    private boolean recording = false;
    private long recordingStartedAt = 0L;
    private File recordingFile;
    private String recordingId;
    private final Map<String, File> recordings = new HashMap<>();
    private File pendingExportFile;

    private boolean receiverRegistered = false;
    private final BroadcastReceiver ttsReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (!TtsService.ACTION_STATUS.equals(intent.getAction())) return;
            JSONObject o = new JSONObject();
            try {
                o.put("state", intent.getStringExtra("state"));
                o.put("message", intent.getStringExtra("message"));
                o.put("position", intent.getIntExtra("position", 0));
                o.put("length", intent.getIntExtra("length", 0));
                o.put("docHash", intent.getStringExtra("docHash"));
                o.put("docName", intent.getStringExtra("docName"));
                o.put("voiceName", intent.getStringExtra("voiceName"));
                o.put("sleepUntil", intent.getLongExtra("sleepUntil", 0L));
            } catch (Exception ignored) { }
            runJs("window.__nativeReaderState && window.__nativeReaderState(" + JSONObject.quote(o.toString()) + ")");
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new TTSBridge(), "AndroidTTS");
        webView.addJavascriptInterface(new RecorderBridge(), "AndroidRecorder");
        webView.addJavascriptInterface(new FilesBridge(), "AndroidFiles");
        webView.loadUrl("file:///android_asset/index.html");

        initPreviewTts();
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATIONS);
        }
    }

    @Override protected void onStart() {
        super.onStart();
        if (!receiverRegistered) {
            IntentFilter f = new IntentFilter(TtsService.ACTION_STATUS);
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(ttsReceiver, f, Context.RECEIVER_NOT_EXPORTED);
            else registerReceiver(ttsReceiver, f);
            receiverRegistered = true;
        }
    }

    @Override protected void onStop() {
        if (receiverRegistered) {
            try { unregisterReceiver(ttsReceiver); } catch (Exception ignored) { }
            receiverRegistered = false;
        }
        super.onStop();
    }

    private void initPreviewTts() {
        previewTts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                previewTtsReady = true;
                previewTts.setLanguage(new Locale("tr", "TR"));
                previewTts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override public void onStart(String utteranceId) { }
                    @Override public void onDone(String utteranceId) {
                        if (utteranceId != null && utteranceId.startsWith("test-")) runJs("window.__voiceTestDone && window.__voiceTestDone(true)");
                    }
                    @Override public void onError(String utteranceId) {
                        if (utteranceId != null && utteranceId.startsWith("test-")) runJs("window.__voiceTestDone && window.__voiceTestDone(false)");
                    }
                    @Override public void onError(String utteranceId, int errorCode) {
                        if (utteranceId != null && utteranceId.startsWith("test-")) runJs("window.__voiceTestDone && window.__voiceTestDone(false)");
                    }
                });
                runJs("window.onNativeTtsReady && window.onNativeTtsReady()");
            }
        });
    }

    private void runJs(String js) {
        if (webView == null) return;
        webView.post(() -> webView.evaluateJavascript(js, null));
    }

    private void sendServiceAction(String action) {
        Intent i = new Intent(this, TtsService.class).setAction(action);
        startService(i);
    }

    public class TTSBridge {
        @JavascriptInterface public boolean isReady() { return previewTtsReady; }

        @JavascriptInterface public String getVoices() {
            JSONArray arr = new JSONArray();
            try {
                if (previewTtsReady && previewTts.getVoices() != null) {
                    for (Voice v : previewTts.getVoices()) {
                        Locale l = v.getLocale();
                        JSONObject o = new JSONObject();
                        o.put("name", v.getName());
                        o.put("lang", l != null ? l.toLanguageTag() : "");
                        o.put("network", v.isNetworkConnectionRequired());
                        o.put("quality", v.getQuality());
                        o.put("latency", v.getLatency());
                        o.put("turkish", l != null && "tr".equalsIgnoreCase(l.getLanguage()));
                        arr.put(o);
                    }
                }
            } catch (Exception ignored) { }
            return arr.toString();
        }

        @JavascriptInterface public void testVoice(String voiceName, float rate, float pitch, float volume) {
            runOnUiThread(() -> {
                if (!previewTtsReady) {
                    runJs("window.__voiceTestDone && window.__voiceTestDone(false)");
                    return;
                }
                Voice chosen = findVoice(voiceName);
                if (chosen != null) previewTts.setVoice(chosen);
                previewTts.setSpeechRate(Math.max(.5f, Math.min(2f, rate)));
                previewTts.setPitch(Math.max(.5f, Math.min(2f, pitch)));
                Bundle b = new Bundle();
                b.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, Math.max(0f, Math.min(1f, volume)));
                String id = "test-" + UUID.randomUUID();
                int r = previewTts.speak("Bu ses çalışıyor. Tezinizi okumaya hazırım.", TextToSpeech.QUEUE_FLUSH, b, id);
                if (r == TextToSpeech.ERROR) runJs("window.__voiceTestDone && window.__voiceTestDone(false)");
            });
        }

        @JavascriptInterface public String start(String text, String docName, String voiceName, float rate, float pitch, float volume, int startPos, int paragraphPauseMs) {
            JSONObject out = new JSONObject();
            try {
                String safeText = text == null ? "" : text;
                if (safeText.trim().isEmpty()) throw new Exception("Metin boş");
                String hash = TtsService.hashText(safeText);
                File dir = new File(getFilesDir(), "reader");
                if (!dir.exists()) dir.mkdirs();
                File f = new File(dir, hash + ".txt");
                try (FileOutputStream fos = new FileOutputStream(f, false)) {
                    fos.write(safeText.getBytes(StandardCharsets.UTF_8));
                }
                getSharedPreferences(TtsService.PREFS, MODE_PRIVATE).edit().putString("active_path", f.getAbsolutePath()).apply();
                Intent i = new Intent(MainActivity.this, TtsService.class).setAction(TtsService.ACTION_START);
                i.putExtra("textPath", f.getAbsolutePath());
                i.putExtra("docHash", hash);
                i.putExtra("docName", docName == null ? "Belge" : docName);
                i.putExtra("voiceName", voiceName == null ? "" : voiceName);
                i.putExtra("rate", rate);
                i.putExtra("pitch", pitch);
                i.putExtra("volume", volume);
                i.putExtra("startPos", Math.max(0, Math.min(startPos, safeText.length())));
                i.putExtra("paragraphPauseMs", paragraphPauseMs);
                startForegroundService(i);
                out.put("ok", true);
                out.put("hash", hash);
            } catch (Exception e) {
                try { out.put("ok", false); out.put("error", e.getMessage()); } catch (Exception ignored) { }
            }
            return out.toString();
        }

        @JavascriptInterface public void pause() { sendServiceAction(TtsService.ACTION_PAUSE); }
        @JavascriptInterface public void resume() { sendServiceAction(TtsService.ACTION_RESUME); }
        @JavascriptInterface public void stop() { sendServiceAction(TtsService.ACTION_STOP); }
        @JavascriptInterface public void back30() { sendServiceAction(TtsService.ACTION_BACK); }
        @JavascriptInterface public void forward30() { sendServiceAction(TtsService.ACTION_FORWARD); }

        @JavascriptInterface public void seekTo(int position) {
            Intent i = new Intent(MainActivity.this, TtsService.class).setAction(TtsService.ACTION_SEEK);
            i.putExtra("position", Math.max(0, position));
            startService(i);
        }

        @JavascriptInterface public void setSleepTimer(int minutes) {
            Intent i = new Intent(MainActivity.this, TtsService.class).setAction(TtsService.ACTION_TIMER);
            i.putExtra("minutes", Math.max(0, minutes));
            startService(i);
        }

        @JavascriptInterface public int getSavedPosition(String text) {
            String hash = TtsService.hashText(text == null ? "" : text);
            return getSharedPreferences(TtsService.PREFS, MODE_PRIVATE).getInt("pos_" + hash, 0);
        }

        @JavascriptInterface public String getState() {
            SharedPreferences p = getSharedPreferences(TtsService.PREFS, MODE_PRIVATE);
            JSONObject o = new JSONObject();
            try {
                o.put("docHash", p.getString("active_hash", ""));
                o.put("docName", p.getString("active_name", ""));
                o.put("position", p.getInt("active_pos", 0));
                o.put("length", p.getInt("active_len", 0));
                o.put("playing", p.getBoolean("active_playing", false));
                o.put("paused", p.getBoolean("active_paused", false));
                o.put("voiceName", p.getString("active_voice", ""));
                o.put("sleepUntil", p.getLong("sleep_until", 0L));
            } catch (Exception ignored) { }
            return o.toString();
        }
    }

    private Voice findVoice(String name) {
        if (!previewTtsReady || previewTts.getVoices() == null || name == null) return null;
        for (Voice v : previewTts.getVoices()) if (name.equals(v.getName())) return v;
        return null;
    }

    public class RecorderBridge {
        @JavascriptInterface public boolean hasPermission() {
            return checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
        }

        @JavascriptInterface public void requestPermission() {
            runOnUiThread(() -> requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO));
        }

        @JavascriptInterface public synchronized boolean startRecording() {
            if (recording) return true;
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                requestPermission();
                return false;
            }
            try {
                File dir = new File(getExternalFilesDir(Environment.DIRECTORY_MUSIC), "SeslendirmeKayitlari");
                if (!dir.exists()) dir.mkdirs();
                recordingId = "take-" + System.currentTimeMillis();
                recordingFile = new File(dir, recordingId + ".m4a");
                recorder = new MediaRecorder();
                recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
                recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
                recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
                recorder.setAudioEncodingBitRate(128000);
                recorder.setAudioSamplingRate(44100);
                recorder.setOutputFile(recordingFile.getAbsolutePath());
                recorder.prepare();
                recorder.start();
                recordingStartedAt = System.currentTimeMillis();
                recording = true;
                return true;
            } catch (Exception e) {
                safeReleaseRecorder();
                return false;
            }
        }

        @JavascriptInterface public synchronized int getAmplitude() {
            if (!recording || recorder == null) return 0;
            try {
                int amp = recorder.getMaxAmplitude();
                double normalized = Math.min(1.0, amp / 32767.0);
                return (int)Math.round(Math.sqrt(normalized) * 100.0);
            } catch (Exception e) { return 0; }
        }

        @JavascriptInterface public synchronized String stopRecording() {
            JSONObject out = new JSONObject();
            if (!recording || recorder == null) {
                try { out.put("ok", false); out.put("error", "Kayıt aktif değil"); } catch (Exception ignored) { }
                return out.toString();
            }
            try {
                recorder.stop();
                long durationMs = Math.max(0L, System.currentTimeMillis() - recordingStartedAt);
                safeReleaseRecorder();
                recording = false;
                recordings.put(recordingId, recordingFile);
                out.put("ok", true);
                out.put("id", recordingId);
                out.put("duration", durationMs / 1000.0);
                out.put("sizeKB", Math.max(1L, recordingFile.length() / 1024L));
                out.put("name", "Kayıt " + recordings.size());
                return out.toString();
            } catch (Exception e) {
                try {
                    safeReleaseRecorder();
                    recording = false;
                    if (recordingFile != null) recordingFile.delete();
                    out.put("ok", false);
                    out.put("error", "Kayıt çok kısa veya tamamlanamadı");
                } catch (Exception ignored) { }
                return out.toString();
            }
        }

        @JavascriptInterface public void play(String id) {
            File f = recordings.get(id);
            if (f == null || !f.exists()) return;
            runOnUiThread(() -> {
                try {
                    MediaPlayer player = new MediaPlayer();
                    player.setDataSource(f.getAbsolutePath());
                    player.setOnPreparedListener(MediaPlayer::start);
                    player.setOnCompletionListener(mp -> { mp.release(); runJs("window.__nativePlaybackEnded && window.__nativePlaybackEnded(" + JSONObject.quote(id) + ")"); });
                    player.setOnErrorListener((mp, what, extra) -> { mp.release(); return true; });
                    player.prepareAsync();
                } catch (Exception ignored) { }
            });
        }

        @JavascriptInterface public void export(String id, String fileName) {
            File f = recordings.get(id);
            if (f == null || !f.exists()) return;
            pendingExportFile = f;
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("audio/mp4");
                i.putExtra(Intent.EXTRA_TITLE, (fileName == null || fileName.isEmpty()) ? "ses-kaydi.m4a" : fileName);
                startActivityForResult(i, REQ_EXPORT_AUDIO);
            });
        }

        @JavascriptInterface public synchronized void delete(String id) {
            File f = recordings.remove(id);
            if (f != null && f.exists()) f.delete();
        }
    }

    private synchronized void safeReleaseRecorder() {
        try { if (recorder != null) recorder.reset(); } catch (Exception ignored) { }
        try { if (recorder != null) recorder.release(); } catch (Exception ignored) { }
        recorder = null;
    }

    public class FilesBridge {
        @JavascriptInterface public void pickTextFile() {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                        "text/plain", "text/markdown", "text/html", "text/csv", "application/json",
                        "application/xml", "text/xml",
                        "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                });
                startActivityForResult(i, REQ_PICK_TEXT);
            });
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();

        if (requestCode == REQ_PICK_TEXT) {
            try {
                String name = getDisplayName(uri);
                String text = name.toLowerCase(Locale.ROOT).endsWith(".docx") ? readDocx(uri) : readUtf8Text(uri);
                if (text.length() > 4_000_000) text = text.substring(0, 4_000_000);
                String js = "window.onNativeFileLoaded && window.onNativeFileLoaded(" + JSONObject.quote(name) + "," + JSONObject.quote(text) + ")";
                runJs(js);
            } catch (Exception e) {
                Toast.makeText(this, "Dosya okunamadı: " + e.getMessage(), Toast.LENGTH_LONG).show();
                runJs("window.onNativeFileError && window.onNativeFileError()");
            }
        } else if (requestCode == REQ_EXPORT_AUDIO && pendingExportFile != null) {
            try (InputStream in = new FileInputStream(pendingExportFile); OutputStream out = getContentResolver().openOutputStream(uri)) {
                if (out == null) throw new Exception("Hedef açılamadı");
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                Toast.makeText(this, "Kayıt kaydedildi", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "Kayıt kaydedilemedi", Toast.LENGTH_LONG).show();
            } finally { pendingExportFile = null; }
        }
    }

    private String getDisplayName(Uri uri) {
        String name = "metin.txt";
        try (Cursor c = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) name = c.getString(0);
        } catch (Exception ignored) { }
        return name == null ? "metin.txt" : name;
    }

    private String readUtf8Text(Uri uri) throws Exception {
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            if (in == null) throw new Exception("Dosya açılamadı");
            byte[] bytes = readAll(in);
            String s = new String(bytes, StandardCharsets.UTF_8);
            if (s.startsWith("\uFEFF")) s = s.substring(1);
            return s;
        }
    }

    private String readDocx(Uri uri) throws Exception {
        try (InputStream raw = getContentResolver().openInputStream(uri); ZipInputStream zip = new ZipInputStream(raw)) {
            ZipEntry entry;
            while ((entry = zip.getNextEntry()) != null) {
                if ("word/document.xml".equals(entry.getName())) {
                    String xml = new String(readAll(zip), StandardCharsets.UTF_8);
                    String text = xml
                            .replaceAll("(?i)</w:p>", "\n")
                            .replaceAll("(?i)<w:tab[^>]*/>", "\t")
                            .replaceAll("(?i)<w:br[^>]*/>", "\n")
                            .replaceAll("<[^>]+>", "");
                    return Html.fromHtml(text, Html.FROM_HTML_MODE_LEGACY).toString().replaceAll("\n{3,}", "\n\n").trim();
                }
            }
        }
        throw new Exception("DOCX metni bulunamadı");
    }

    private byte[] readAll(InputStream in) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        return out.toByteArray();
    }

    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        try { if (previewTts != null) { previewTts.stop(); previewTts.shutdown(); } } catch (Exception ignored) { }
        if (recording) {
            try { recorder.stop(); } catch (Exception ignored) { }
            safeReleaseRecorder();
        }
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
