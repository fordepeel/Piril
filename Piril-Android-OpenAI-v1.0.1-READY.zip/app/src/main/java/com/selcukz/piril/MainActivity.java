package com.selcukz.piril;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.util.Base64;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.SslErrorHandler;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.net.http.SslError;

public final class MainActivity extends Activity {
    private static final int REQUEST_RECORD_AUDIO = 4107;
    private static final String START_URL = "file:///android_asset/www/index.html";
    private static final String ASSET_PREFIX = "file:///android_asset/www/";
    private static final String OPENAI_URL = "https://api.openai.com/v1/responses";
    private static final int MAX_REQUEST_BYTES = 5 * 1024 * 1024;
    private static final int MAX_RESPONSE_BYTES = 8 * 1024 * 1024;

    private WebView webView;
    private SpeechRecognizer speechRecognizer;
    private TextToSpeech textToSpeech;
    private boolean textToSpeechReady;
    private boolean pendingRecognitionStart;
    private boolean recognitionActive;
    private final ExecutorService networkExecutor = Executors.newSingleThreadExecutor();
    private SecureApiKeyStore apiKeyStore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        apiKeyStore = new SecureApiKeyStore(this);
        configureWebView();
        initializeTextToSpeech();
        hideSystemBars();
        webView.loadUrl(START_URL);
    }

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    private void configureWebView() {
        WebView.setWebContentsDebuggingEnabled(false);
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(255, 248, 237));

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setDefaultTextEncodingName("UTF-8");
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setUserAgentString(settings.getUserAgentString() + " PirilAndroid/1.0.1");
        settings.setSafeBrowsingEnabled(true);

        webView.addJavascriptInterface(new AndroidBridge(), "PirilAndroid");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String target = uri == null ? "" : uri.toString();
                if (target.startsWith(ASSET_PREFIX)) {
                    return false;
                }
                if ("https".equalsIgnoreCase(uri == null ? "" : uri.getScheme())) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, uri));
                    } catch (ActivityNotFoundException ignored) {
                    }
                }
                return true;
            }

            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                handler.cancel();
            }
        });

        setContentView(webView);
    }

    private void initializeTextToSpeech() {
        textToSpeech = new TextToSpeech(getApplicationContext(), status -> {
            if (status != TextToSpeech.SUCCESS) {
                textToSpeechReady = false;
                return;
            }
            int languageStatus = textToSpeech.setLanguage(new Locale("tr", "TR"));
            textToSpeechReady = languageStatus != TextToSpeech.LANG_MISSING_DATA
                    && languageStatus != TextToSpeech.LANG_NOT_SUPPORTED;
            textToSpeech.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override
                public void onStart(String utteranceId) {
                    callJs("onSpeechStart");
                }

                @Override
                public void onDone(String utteranceId) {
                    if (utteranceId != null && utteranceId.endsWith("-last")) {
                        callJs("onSpeechEnd");
                    }
                }

                @Override
                public void onError(String utteranceId) {
                    callJs("onSpeechError", "Seslendirme tamamlanamadı");
                }
            });
            callJs("onTtsReady", textToSpeechReady);
        });
    }

    private void startRecognition() {
        runOnUiThread(() -> {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                pendingRecognitionStart = true;
                requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_RECORD_AUDIO);
                return;
            }
            startRecognitionWithPermission();
        });
    }

    private void startRecognitionWithPermission() {
        pendingRecognitionStart = false;
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            callJs("onRecognitionError", "service-not-allowed");
            return;
        }
        if (speechRecognizer == null) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
            speechRecognizer.setRecognitionListener(new RecognitionListener() {
                @Override
                public void onReadyForSpeech(Bundle params) {
                    recognitionActive = true;
                    callJs("onRecognitionStart");
                }

                @Override public void onBeginningOfSpeech() { }
                @Override public void onRmsChanged(float rmsdB) { }
                @Override public void onBufferReceived(byte[] buffer) { }

                @Override
                public void onEndOfSpeech() {
                    recognitionActive = false;
                    callJs("onRecognitionEnd");
                }

                @Override
                public void onError(int error) {
                    recognitionActive = false;
                    callJs("onRecognitionError", mapSpeechError(error));
                    callJs("onRecognitionEnd");
                }

                @Override
                public void onResults(Bundle results) {
                    recognitionActive = false;
                    ArrayList<String> matches = results == null
                            ? null
                            : results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (matches == null || matches.isEmpty() || matches.get(0).trim().isEmpty()) {
                        callJs("onRecognitionError", "no-speech");
                    } else {
                        callJs("onRecognitionResult", matches.get(0).trim());
                    }
                    callJs("onRecognitionEnd");
                }

                @Override public void onPartialResults(Bundle partialResults) { }
                @Override public void onEvent(int eventType, Bundle params) { }
            });
        }

        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR");
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "tr-TR");
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
        intent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getPackageName());
        try {
            speechRecognizer.startListening(intent);
        } catch (RuntimeException error) {
            callJs("onRecognitionError", "service-not-allowed");
        }
    }

    private void stopRecognition() {
        runOnUiThread(() -> {
            if (speechRecognizer != null) {
                try {
                    speechRecognizer.stopListening();
                } catch (RuntimeException ignored) {
                }
            }
        });
    }

    private static String mapSpeechError(int error) {
        switch (error) {
            case SpeechRecognizer.ERROR_AUDIO:
                return "audio-capture";
            case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS:
                return "not-allowed";
            case SpeechRecognizer.ERROR_NETWORK:
            case SpeechRecognizer.ERROR_NETWORK_TIMEOUT:
                return "network";
            case SpeechRecognizer.ERROR_NO_MATCH:
            case SpeechRecognizer.ERROR_SPEECH_TIMEOUT:
                return "no-speech";
            case SpeechRecognizer.ERROR_RECOGNIZER_BUSY:
                return "aborted";
            case SpeechRecognizer.ERROR_CLIENT:
                return "aborted";
            case SpeechRecognizer.ERROR_SERVER:
            case SpeechRecognizer.ERROR_SERVER_DISCONNECTED:
                return "service-not-allowed";
            case SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED:
            case SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE:
                return "language-not-supported";
            default:
                return "unknown";
        }
    }

    private void speak(String text, float rate, float pitch) {
        runOnUiThread(() -> {
            String clean = text == null ? "" : text.trim();
            if (clean.isEmpty()) {
                callJs("onSpeechEnd");
                return;
            }
            if (!textToSpeechReady || textToSpeech == null) {
                callJs("onSpeechError", "Türkçe ses verisi bulunamadı");
                return;
            }
            textToSpeech.stop();
            textToSpeech.setLanguage(new Locale("tr", "TR"));
            textToSpeech.setSpeechRate(clamp(rate, 0.55f, 1.45f));
            textToSpeech.setPitch(clamp(pitch, 0.65f, 1.65f));

            List<String> chunks = splitForSpeech(clean, Math.min(3000, TextToSpeech.getMaxSpeechInputLength()));
            String group = "piril-" + System.nanoTime();
            for (int index = 0; index < chunks.size(); index++) {
                boolean first = index == 0;
                boolean last = index == chunks.size() - 1;
                String utteranceId = group + (last ? "-last" : "-" + index);
                textToSpeech.speak(
                        chunks.get(index),
                        first ? TextToSpeech.QUEUE_FLUSH : TextToSpeech.QUEUE_ADD,
                        null,
                        utteranceId
                );
            }
        });
    }

    private static List<String> splitForSpeech(String text, int maxLength) {
        List<String> result = new ArrayList<>();
        String remaining = text.trim();
        while (remaining.length() > maxLength) {
            int cut = remaining.lastIndexOf('.', maxLength);
            if (cut < maxLength / 2) cut = remaining.lastIndexOf(' ', maxLength);
            if (cut < maxLength / 2) cut = maxLength;
            int end = cut;
            int next = cut;
            if (cut < remaining.length() && remaining.charAt(cut) == '.') {
                end = cut + 1;
                next = end;
            } else if (cut < remaining.length() && Character.isWhitespace(remaining.charAt(cut))) {
                next = cut + 1;
            }
            result.add(remaining.substring(0, end).trim());
            remaining = remaining.substring(next).trim();
        }
        if (!remaining.isEmpty()) result.add(remaining);
        return result;
    }

    private static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }

    private void requestOpenAI(String requestId, String body) {
        if (requestId == null || requestId.length() > 100 || body == null) {
            callJs("onOpenAIResponse", requestId == null ? "" : requestId, false, 0, "INVALID_REQUEST");
            return;
        }
        byte[] bodyBytes = body.getBytes(StandardCharsets.UTF_8);
        if (bodyBytes.length > MAX_REQUEST_BYTES) {
            callJs("onOpenAIResponse", requestId, false, 413, "REQUEST_TOO_LARGE");
            return;
        }

        networkExecutor.execute(() -> {
            String apiKey = apiKeyStore.load();
            if (apiKey.isEmpty()) {
                callJs("onOpenAIResponse", requestId, false, 401, "NOKEY");
                return;
            }

            HttpURLConnection connection = null;
            try {
                connection = (HttpURLConnection) new URL(OPENAI_URL).openConnection();
                connection.setRequestMethod("POST");
                connection.setConnectTimeout(30_000);
                connection.setReadTimeout(90_000);
                connection.setDoOutput(true);
                connection.setUseCaches(false);
                connection.setRequestProperty("Content-Type", "application/json");
                connection.setRequestProperty("Accept", "application/json");
                connection.setRequestProperty("Authorization", "Bearer " + apiKey);
                connection.setRequestProperty("User-Agent", "Piril-Android/1.0.1");
                connection.setFixedLengthStreamingMode(bodyBytes.length);

                try (OutputStream output = connection.getOutputStream()) {
                    output.write(bodyBytes);
                }

                int status = connection.getResponseCode();
                InputStream stream = status >= 200 && status < 300
                        ? connection.getInputStream()
                        : connection.getErrorStream();
                String response = readStream(stream, MAX_RESPONSE_BYTES);
                callJs("onOpenAIResponse", requestId, status >= 200 && status < 300, status, response);
            } catch (Exception error) {
                callJs("onOpenAIResponse", requestId, false, 0, "NETWORK_ERROR");
            } finally {
                if (connection != null) connection.disconnect();
            }
        });
    }

    private static String readStream(InputStream input, int maximumBytes) throws Exception {
        if (input == null) return "";
        try (InputStream stream = input; ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int total = 0;
            int read;
            while ((read = stream.read(buffer)) != -1) {
                total += read;
                if (total > maximumBytes) throw new IllegalStateException("Response too large");
                output.write(buffer, 0, read);
            }
            return output.toString(StandardCharsets.UTF_8.name());
        }
    }

    private void callJs(String method, Object... values) {
        if (webView == null) return;
        StringBuilder script = new StringBuilder("window.PirilNative&&window.PirilNative.")
                .append(method)
                .append('(');
        for (int index = 0; index < values.length; index++) {
            if (index > 0) script.append(',');
            Object value = values[index];
            if (value == null) script.append("null");
            else if (value instanceof Boolean || value instanceof Number) script.append(value);
            else script.append(JSONObject.quote(String.valueOf(value)));
        }
        script.append(");");
        String javascript = script.toString();
        runOnUiThread(() -> {
            if (webView != null) webView.evaluateJavascript(javascript, null);
        });
    }

    private void openTextToSpeechSettings() {
        runOnUiThread(() -> {
            try {
                startActivity(new Intent("com.android.settings.TTS_SETTINGS"));
            } catch (ActivityNotFoundException first) {
                try {
                    startActivity(new Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA));
                } catch (ActivityNotFoundException second) {
                    startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
                }
            }
        });
    }

    private void hideSystemBars() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        );
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemBars();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQUEST_RECORD_AUDIO) return;
        boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
        if (granted && pendingRecognitionStart) {
            pendingRecognitionStart = false;
            startRecognitionWithPermission();
        } else {
            pendingRecognitionStart = false;
            callJs("onRecognitionError", "not-allowed");
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        stopRecognition();
        if (textToSpeech != null) textToSpeech.stop();
    }

    @Override
    protected void onResume() {
        super.onResume();
        hideSystemBars();
    }

    @Override
    protected void onDestroy() {
        if (speechRecognizer != null) {
            speechRecognizer.cancel();
            speechRecognizer.destroy();
        }
        if (textToSpeech != null) {
            textToSpeech.stop();
            textToSpeech.shutdown();
        }
        networkExecutor.shutdownNow();
        if (webView != null) {
            webView.removeJavascriptInterface("PirilAndroid");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }

    public final class AndroidBridge {
        @JavascriptInterface
        public String platform() {
            return "android";
        }

        @JavascriptInterface
        public boolean hasApiKey() {
            return !apiKeyStore.load().isEmpty();
        }

        @JavascriptInterface
        public String apiKeySuffix() {
            String key = apiKeyStore.load();
            return key.length() <= 4 ? key : key.substring(key.length() - 4);
        }

        @JavascriptInterface
        public boolean saveApiKey(String key) {
            String normalized = key == null ? "" : key.trim();
            if (normalized.isEmpty()) {
                apiKeyStore.clear();
                return true;
            }
            if (!normalized.startsWith("sk-") || normalized.length() < 20) return false;
            return apiKeyStore.save(normalized);
        }

        @JavascriptInterface
        public void startRecognition() {
            MainActivity.this.startRecognition();
        }

        @JavascriptInterface
        public void stopRecognition() {
            MainActivity.this.stopRecognition();
        }

        @JavascriptInterface
        public boolean recognitionAvailable() {
            return SpeechRecognizer.isRecognitionAvailable(MainActivity.this);
        }

        @JavascriptInterface
        public void speak(String text, float rate, float pitch) {
            MainActivity.this.speak(text, rate, pitch);
        }

        @JavascriptInterface
        public void stopSpeaking() {
            runOnUiThread(() -> {
                if (textToSpeech != null) textToSpeech.stop();
            });
        }

        @JavascriptInterface
        public boolean ttsReady() {
            return textToSpeechReady;
        }

        @JavascriptInterface
        public void openTtsSettings() {
            openTextToSpeechSettings();
        }

        @JavascriptInterface
        public void requestOpenAI(String requestId, String jsonBody) {
            MainActivity.this.requestOpenAI(requestId, jsonBody);
        }
    }

    private static final class SecureApiKeyStore {
        private static final String ANDROID_KEY_STORE = "AndroidKeyStore";
        private static final String KEY_ALIAS = "piril_openai_key_v1";
        private static final String PREFS = "piril_secure_preferences";
        private static final String PREF_IV = "api_iv";
        private static final String PREF_DATA = "api_data";
        private final SharedPreferences preferences;

        SecureApiKeyStore(Context context) {
            preferences = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        }

        synchronized boolean save(String apiKey) {
            try {
                Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
                cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey());
                byte[] encrypted = cipher.doFinal(apiKey.getBytes(StandardCharsets.UTF_8));
                return preferences.edit()
                        .putString(PREF_IV, Base64.encodeToString(cipher.getIV(), Base64.NO_WRAP))
                        .putString(PREF_DATA, Base64.encodeToString(encrypted, Base64.NO_WRAP))
                        .commit();
            } catch (Exception error) {
                return false;
            }
        }

        synchronized String load() {
            String ivText = preferences.getString(PREF_IV, "");
            String dataText = preferences.getString(PREF_DATA, "");
            if (ivText.isEmpty() || dataText.isEmpty()) return "";
            try {
                Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
                cipher.init(
                        Cipher.DECRYPT_MODE,
                        getOrCreateKey(),
                        new GCMParameterSpec(128, Base64.decode(ivText, Base64.NO_WRAP))
                );
                byte[] clear = cipher.doFinal(Base64.decode(dataText, Base64.NO_WRAP));
                return new String(clear, StandardCharsets.UTF_8);
            } catch (Exception error) {
                clear();
                return "";
            }
        }

        synchronized void clear() {
            preferences.edit().remove(PREF_IV).remove(PREF_DATA).commit();
        }

        private SecretKey getOrCreateKey() throws Exception {
            KeyStore keyStore = KeyStore.getInstance(ANDROID_KEY_STORE);
            keyStore.load(null);
            KeyStore.Entry existing = keyStore.getEntry(KEY_ALIAS, null);
            if (existing instanceof KeyStore.SecretKeyEntry) {
                return ((KeyStore.SecretKeyEntry) existing).getSecretKey();
            }

            KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEY_STORE);
            generator.init(new KeyGenParameterSpec.Builder(
                    KEY_ALIAS,
                    KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT
            )
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setRandomizedEncryptionRequired(true)
                    .build());
            return generator.generateKey();
        }
    }
}
