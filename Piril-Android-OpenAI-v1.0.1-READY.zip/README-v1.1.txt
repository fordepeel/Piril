SESLENDIRME STUDYOSU v1.1 - TEZ OKUYUCU

- Uzun metinleri Android TTS sinirina takilmadan dogal parcalara boler.
- Foreground Service ile ekran kapaliyken / baska uygulamadayken okumaya devam eder.
- Bildirimden 30 sn geri, duraklat/devam, 30 sn ileri ve durdur.
- Belgeye ozel kaldigin yeri hatirlar.
- DOCX ve metin tabanli dosya yukleme.
- Basliklardan otomatik bolum navigasyonu.
- Yer imleri.
- Uyku zamanlayicisi.
- Yerel / ag sesi ayrimi ve ses test butonu.
- Calismayan secili ses icin yerel Turkce sese otomatik geri donus.
- Akademik filtreler: kaynakcayi, yil iceren parantez ici atiflari, URL/DOI adreslerini istege bagli sessiz gecme.
- Paragraf arasi nefes suresi.
- Native M4A ses kaydi ve disa aktarma.

Not: v1.1 ile sabit imza anahtari kullanilmaya baslanmistir. Onceki CI debug APK'si farkli imzaliysa v1.0 once kaldirilmalidir. Bundan sonraki v1.1+ surumleri birbirinin uzerine kurulabilir.

FIX v1.1.1: Android API 35 uyumluluğu için Files.readString kaldırıldı.
